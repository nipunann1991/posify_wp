<?php
$output = $el_class = $width = $offset = '';
extract(shortcode_atts(array(
  'el_class' 	=> '',
  'width' 		=> '1/1',
  'offset'		=> '',
  'clear'		=> '',
), $atts));

$columns_size = explode('/', $width);
if( is_array($columns_size) && !empty($columns_size[1]) && (12 % $columns_size[1] === 0) ){
	$carp = 12 / $columns_size[1];
	$width = $carp * $columns_size[0];
}else{
	$width = '12';
}

$column_prefix = ( function_exists('ts_get_option') && !ts_get_option( 'slupy_responsive' ) ) ? 'col-lg-' : 'col-sm-';

$column_classes = $column_prefix.$width;

if( $column_prefix === 'col-sm-' && $offset ) {
	$offset = str_replace('vc_', '', $offset);
	$column_classes = preg_match('/col\-sm\-\d+/', $offset) ? $offset : $column_classes.' '.$offset;
}

$css_class = 'column-container '.$column_classes.($el_class != '' ? ' '.$el_class : '');

$output .= '<div class="'.esc_attr( $css_class ).'">';
$output .= wpb_js_remove_wpautop($content);
$output .= '</div>';

if( $clear ) {
	$clear_class = strpos($clear, 'lg') !== false ? ' visible-lg' : ' hidden-lg';
	$clear_class .= strpos($clear, 'md') !== false ? ' visible-md' : ' hidden-md';
	$clear_class .= strpos($clear, 'sm') !== false ? ' visible-sm' : ' hidden-sm';
	$clear_class .= strpos($clear, 'xs') !== false ? ' visible-xs' : ' hidden-xs';

	$output .= '<div class="clearfix'.esc_attr( $clear_class ).'"></div>';
}


echo $output;