<?php
extract( shortcode_atts( array(
  'id'                      => '',
  'el_class'                => '',
  'bg_typeimage'            => 'off',
  'bg_image'                => '',
  'bg_color'                => '',
  'bg_repeat'               => '',
  'bg_attachment'           => '',
  'bg_position'             => '',
  'parallax'                => 'off',
  'parallax_speed'          => '7',
  'parallax_offset'         => '',
  'bg_typevideo'            => 'off',
  'bg_video_mp4'            => '',
  'bg_video_webm'           => '',
  'bg_video_ogv'            => '',
  'bg_video_poster'         => '',
  'bg_video_sound'          => 'off',
  'bg_video_loop'           => 'off',
  'cover_color'             => '',
  'font_color'              => '',
  'padding'                 => '',
  'space'                   => '',
  'margin_bottom'           => '',
  'disable_container'       => 'off',
  'cover_color_alpha'       => '1',
  'disable_padding_columns' => 'off'
  ), $atts ) );

  $output = '';

  //row custom styles
  $style = '';
  if ( $bg_image ) {
    $bg_typeimage = 'on';
    $get_image_src = wp_get_attachment_image_src( $bg_image, 'full' );
    $style .= !empty( $get_image_src[0] ) ? 'background-image:url('.esc_url( $get_image_src[0] ).'); ' : '';
    $style .= $bg_repeat ? 'background-repeat:'.$bg_repeat.'; ' : '';
    $style .= $bg_attachment ? 'background-attachment:'.$bg_attachment.'; ' : '';
    $style .= $bg_position ? 'background-position:'.$bg_position.'; ' : '';
  }

  $style .= $bg_color ? 'background-color:'.$bg_color.'; ' : '';
  $style .= $font_color ? 'color:'.$font_color.'; ' : '';
  $style .= $padding ? 'padding:'.$padding.'; ' : '';
  $style .= $margin_bottom ? 'margin-bottom:'.$margin_bottom.'; ' : '';

  //background video
  $video_cover = '';
  $video_cover .= $cover_color ? '<div class="section-cover" style="background-color:'.esc_attr( $cover_color ).'; opacity:'.esc_attr( $cover_color_alpha ).';"></div>' : '';

  if ( ($bg_video_mp4 || $bg_video_ogv || $bg_video_webm )  && $bg_typeimage == 'off' ) {
    $bg_typevideo = 'on';
    $video_output = '';
    $video_output .= $bg_video_mp4 && strpos( $bg_video_mp4, '.mp4' ) ? '<source type="video/mp4" src="'.esc_url( $bg_video_mp4 ).'" />' : '';
    $video_output .= $bg_video_ogv && strpos( $bg_video_ogv, '.ogv' ) ? '<source type="video/ogg" src="'.esc_url( $bg_video_ogv ).'" />' : '';
    $video_output .= $bg_video_webm && strpos( $bg_video_webm, '.webm' ) ? '<source type="video/webm" src="'.esc_url( $bg_video_webm ).'" />' : '';

    if ( $video_output ) {
      wp_enqueue_style( 'mediaelement' );
      wp_enqueue_script( 'mediaelement' );

      //video attributes
      $video_attr = '';
      $video_attr .= 'width="320" ';
      $video_attr .= 'height="240" ';
      $video_attr .= 'autoplay="autoplay" ';
      $video_attr .= $bg_video_poster ? 'poster="'.esc_url( $bg_video_poster ).'" ' : '';
      $video_attr .= $bg_video_sound == 'off' ? 'muted="muted" ' : '';
      $video_attr .= $bg_video_loop == 'on' ? 'loop="loop" ' : '';

      $video_cover .= '<div class="section-bgvideo">';
      $video_cover .= '<div class="bg-video"><video '.$video_attr.'>';
      $video_cover .= $video_output;
      $video_cover .= '</video></div>';
      $video_cover .= '</div>';
    }
  }

  //parallax attributes
  $section_attr = '';
  if ( $parallax == 'on' && !empty( $get_image_src[0] ) ) {
    $section_attr .= ' data-parallax="background"';
    $section_attr .= ' data-speed="'.esc_attr( $parallax_speed ).'"';
    $section_attr .= $parallax_offset ? ' data-offset="'.esc_attr( $parallax_offset ).'"' : '';
  }

  if ( $style ) {
    $section_attr .= ' style="'.$style.'"';
  }

  if( $id ) {
    $section_attr .= ' id="'.$id.'"';
  }

  //row class
  $css_class = 'row'.($el_class ? ' '.$el_class : '');
  $css_class.= $disable_padding_columns == 'on' ? ' no-padding' : '';
  $css_class.= ($cover_color || $bg_typevideo == 'on' ? ' is-media-container' : '');
  $css_class.= $space ? ' '.$space : '';

  //Full width page control
  $full_with_is_active = false;
  global $slupy_page_type_full_width;

  if ( isset($slupy_page_type_full_width) ) {
    $output .= '<div class="container-fluid"'.$section_attr.'>';
    $output .= $disable_container != 'on' ? '<div class="container">' : '';
    $full_with_is_active = true;
  }

  $output .= '<div class="'.esc_attr( $css_class ).'"'.( !$full_with_is_active ? $section_attr : '' ).'>';
  $output .= wpb_js_remove_wpautop( $content );
  $output .= !$full_with_is_active ? $video_cover : '';
  $output .= '</div>';

  $output .= $disable_container != 'on' && $full_with_is_active ? '</div>' : '';

  if ( $full_with_is_active ) {
    $output .= $video_cover;
    $output .= '</div>';
  }

  if( $this->settings['base'] == 'vc_row_inner' ){
    $output = '<div class="row">'.wpb_js_remove_wpautop( $content ).'</div>';
  }

  echo $output;