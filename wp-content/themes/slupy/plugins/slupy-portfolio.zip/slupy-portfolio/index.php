<?php
/*
Plugin Name: Slupy Portfolio
Plugin URI: http://www.themesama.com/
Description: Register Portfolio Taxonomy and Post Type for Slupy Theme
Version: 1.0
Author: ThemeSama
Author URI: http://www.themesama.com
*/

// don't load directly
if (!defined('ABSPATH')) die('-1');

/*---------------------------------------------
  Slupy Portfolio
---------------------------------------------*/
if ( !class_exists( 'Slupy_Portfolio' ) ) {

  class Slupy_Portfolio {

    function __construct() {

      defined( 'P_SLUG' ) ||  define( 'P_SLUG', 'portfolio' );

      add_action( 'init', array( &$this, 'portfolio_init' ) );

    }

    /*---------------------------------------------
      Register Post Type
    ---------------------------------------------*/
    function portfolio_init() {
      if( defined( 'IS_SLUPY' ) ){

        $labels = array(
          'name'               => _x( 'Portfolio', 'post type general name', SLUPY_TRANSLATE ),
          'singular_name'      => _x( 'Work', 'post type singular name', SLUPY_TRANSLATE ),
          'menu_name'          => _x( 'Portfolio', 'admin menu', SLUPY_TRANSLATE ),
          'name_admin_bar'     => _x( 'Work', 'add new on admin bar', SLUPY_TRANSLATE ),
          'add_new'            => _x( 'Add New', 'portfolio', SLUPY_TRANSLATE ),
          'add_new_item'       => __( 'Add New Work', SLUPY_TRANSLATE ),
          'new_item'           => __( 'New Work', SLUPY_TRANSLATE ),
          'edit_item'          => __( 'Edit Work', SLUPY_TRANSLATE ),
          'view_item'          => __( 'View Work', SLUPY_TRANSLATE ),
          'all_items'          => __( 'All Works', SLUPY_TRANSLATE ),
          'search_items'       => __( 'Search Works', SLUPY_TRANSLATE ),
          'parent_item_colon'  => __( 'Parent Works', SLUPY_TRANSLATE ),
          'not_found'          => __( 'No works found.', SLUPY_TRANSLATE ),
          'not_found_in_trash' => __( 'No works found in Trash.', SLUPY_TRANSLATE ),
        );

        $args = array(
          'labels'             => $labels,
          'public'             => true,
          'publicly_queryable' => true,
          'show_ui'            => true,
          'show_in_menu'       => true,
          'query_var'          => true,
          'rewrite'            => array( 'slug' => P_SLUG.'-item' ),
          'capability_type'    => 'post',
          'has_archive'        => true,
          'hierarchical'       => false,
          'menu_position'      => null,
          'menu_icon'          => 'dashicons-portfolio',
          'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'comments' )
        );

        register_post_type( P_SLUG, $args );
        register_taxonomy( P_SLUG.'_cat', P_SLUG, array( 'hierarchical' => true, 'query_var' => true, 'rewrite' => true ) );
      }
    }

  }

}

new Slupy_Portfolio;

?>