<?php
/**
 * WPBakery Visual Composer Shortcodes settings
 *
 * @package VPBakeryVisualComposer
 *
 */
function vc_map_default_shortcodes() {

  vc_map( array(
    'name'              => __('Row', 'js_composer'),
    'base'              => 'vc_row',
    'is_container'      => true,
    'icon'              => 'fa-plus-square-o',
    'category'          => __('Content', 'js_composer'),
    'description'       => __('Place content elements inside the row', 'js_composer'),
    'js_view'           => 'VcRowView',
    'params'            => array(
      array(
        'type'          => 'colorpicker',
        'heading'       => __( 'Font Color', 'js_composer' ),
        'param_name'    => 'font_color',
        'group'         => __( 'Style', 'js_composer' )
      ),
      array(
        'type'          => 'colorpicker',
        'heading'       => __( 'Background Color', 'js_composer' ),
        'param_name'    => 'bg_color',
        'group'         => __( 'Style', 'js_composer' )
      ),
      array(
        'type'          => 'switch_slupy',
        'heading'       => __( 'Disable Columns Padding', 'js_composer' ),
        'param_name'    => 'disable_padding_columns',
        'group'         => __( 'Style', 'js_composer' )
      ),
      array(
        'type'          => 'switch_slupy',
        'heading'       => __( 'Disable Container', 'js_composer' ),
        'param_name'    => 'disable_container',
        'group'         => __( 'Style', 'js_composer' )
      ),
      array(
        'type'          => 'dropdown',
        'heading'       => __('Row Space','js_composer'),
        'param_name'    => 'space',
        'value'         => array(
            '' => '',
            __('X-Small', 'js_composer')    => 'space-20',
            __('Small', 'js_composer')      => 'space-30',
            __('Medium', 'js_composer')     => 'space-40',
            __('Large', 'js_composer')      => 'space-60',
            __('X-Large', 'js_composer')    => 'space-90',
            __('XX-Large', 'js_composer')   => 'space-120'
        ),
        'class'         => '',
        'group'         => __( 'Style', 'js_composer' )
      ),
      array(
        'type'          => 'textfield',
        'heading'       => __( 'Bottom Margin', 'js_composer' ),
        'param_name'    => 'margin_bottom',
        'group'         => __( 'Style', 'js_composer' )
      ),
      array(
        'type'          => 'textfield',
        'heading'       => __( 'Extra Class', 'js_composer' ),
        'param_name'    => 'el_class',
        'group'         => __( 'Style', 'js_composer' )
      ),
      array(
        'type'          => 'textfield',
        'heading'       => __( 'ID', 'js_composer' ),
        'param_name'    => 'id',
        'group'         => __( 'Style', 'js_composer' )
      ),
      array(
        'type'          => 'attach_image',
        'heading'       => __( 'Background Image', 'js_composer' ),
        'param_name'    => 'bg_image',
        'group'         => __( 'Image BG', 'js_composer' )
      ),
      array(
        'type'          => 'switch_slupy',
        'heading'       => __( 'Parallax Background', 'js_composer' ),
        'param_name'    => 'parallax',
        'value'         => 'off',
        'group'         => __( 'Image BG', 'js_composer' )
      ),
      array(
        'type'          => 'textfield',
        'heading'       => __( 'Parallax Speed', 'js_composer' ),
        'param_name'    => 'parallax_speed',
        'value'         => '0.2',
        'dependency'    => array( 'element' => 'parallax', 'value' => array( 'on' ) ),
        'group'         => __( 'Image BG', 'js_composer' )
      ),
      array(
        'type'          => 'textfield',
        'heading'       => __( 'Parallax Offset', 'js_composer' ),
        'param_name'    => 'parallax_offset',
        'dependency'    => array( 'element' => 'parallax', 'value' => array( 'on' ) ),
        'group'         => __( 'Image BG', 'js_composer' )
      ),
      array(
        'type'          => 'dropdown',
        'heading'       => __( 'Background Repeat', 'js_composer' ),
        'param_name'    => 'bg_repeat',
        'value'         => array(
          __( 'Repeat All', 'js_composer' )           => '',
          __( 'No Repeat', 'js_composer' )            => 'no-repeat',
          __( 'Repeat Horizontally', 'js_composer' )  => 'repeat-x',
          __( 'Repeat Vertically', 'js_composer' )    => 'repeat-y'
        ),
        'dependency'    => array( 'element' => 'parallax', 'value' => array( 'off' ) ),
        'group'         => __( 'Image BG', 'js_composer' )
      ),
      array(
        'type'          => 'dropdown',
        'heading'       => __( 'Background Attachment', 'js_composer' ),
        'param_name'    => 'bg_attachment',
        'value'         => array(
          __( 'Scroll', 'js_composer' ) => '',
          __( 'Fixed', 'js_composer' )  => 'fixed'
        ),
        'dependency'    => array( 'element' => 'parallax', 'value' => array( 'off' ) ),
        'group'         => __( 'Image BG', 'js_composer' )
      ),
      array(
        'type'          => 'dropdown',
        'heading'       => __( 'Background Position', 'js_composer' ),
        'param_name'    => 'bg_position',
        'value'         => array(
          __( 'Left Top', 'js_composer' )       => '',
          __( 'Left Center', 'js_composer' )    => 'left center',
          __( 'Left Bottom', 'js_composer' )    => 'left bottom',
          __( 'Center Top', 'js_composer' )     => 'center top',
          __( 'Center Center', 'js_composer' )  => 'center center',
          __( 'Center Bottom', 'js_composer' )  => 'center bottom',
          __( 'Right Top', 'js_composer' )      => 'right top',
          __( 'Right Center', 'js_composer' )   => 'right center',
          __( 'Right Bottom', 'js_composer' )   => 'right bottom'
        ),
        'dependency'    => array( 'element' => 'parallax', 'value' => array( 'off' ) ),
        'group'         => __( 'Image BG', 'js_composer' )
      ),
      array(
        'type'          => 'upload_slupy',
        'heading'       => __( 'Video (.mp4)', 'js_composer' ),
        'param_name'    => 'bg_video_mp4',
        'file_type'     => 'video',
        'group'         => __( 'Video BG', 'js_composer' )
      ),
      array(
        'type'          => 'upload_slupy',
        'heading'       => __( 'Video (.webm)', 'js_composer' ),
        'param_name'    => 'bg_video_webm',
        'file_type'     => 'video',
        'group'         => __( 'Video BG', 'js_composer' )
      ),
      array(
        'type'          => 'upload_slupy',
        'heading'       => __( 'Video (.ogv)', 'js_composer' ),
        'param_name'    => 'bg_video_ogv',
        'file_type'     => 'video',
        'group'         => __( 'Video BG', 'js_composer' )
      ),
      array(
        'type'          => 'upload_slupy',
        'heading'       => __( 'Video Poster', 'js_composer' ),
        'param_name'    => 'bg_video_poster',
        'group'         => __( 'Video BG', 'js_composer' )
      ),
      array(
        'type'          => 'switch_slupy',
        'heading'       => __( 'Video Sound', 'js_composer' ),
        'param_name'    => 'bg_video_sound',
        'group'         => __( 'Video BG', 'js_composer' )
      ),
      array(
        'type'          => 'switch_slupy',
        'heading'       => __( 'Video Loop', 'js_composer' ),
        'param_name'    => 'bg_video_loop',
        'group'         => __( 'Video BG', 'js_composer' )
      ),
      array(
        'type'          => 'colorpicker',
        'heading'       => __( 'Cover Color', 'js_composer' ),
        'param_name'    => 'cover_color',
        'description'   => __( 'If you use a image or video background you can choose a cover color.', 'js_composer' ),
        'group'         => __( 'BG Cover', 'js_composer' )
      )
    ),
    'show_settings_on_create' => false
  ) );

  vc_map( array(
    'name'              => __('Row', 'js_composer'), //Inner Row
    'base'              => 'vc_row_inner',
    'icon'              => '',
    'content_element'   => false,
    'is_container'      => true,
    'weight'            => 1000,
    'js_view'           => 'VcRowView',
    'params'            => array(
      array(
        'type'          => 'textfield',
        'heading'       => __('Extra Class', 'js_composer'),
        'param_name'    => 'el_class'
      )
    ),
    'show_settings_on_create' => false
  ) );

  vc_map( array(
    'name'              => __('Column', 'js_composer'),
    'base'              => 'vc_column',
    'is_container'      => true,
    'js_view'           => 'VcColumnView',
    'content_element'   => false,
    'params'            => array(
      array(
        'type'          => 'dropdown',
        'heading'       => __( 'Width', 'js_composer' ),
        'param_name'    => 'width',
        'value'         => array(
          __('1 column - 1/12', 'js_composer')    => '1/12',
          __('2 columns - 1/6', 'js_composer')    => '1/6',
          __('3 columns - 1/4', 'js_composer')    => '1/4',
          __('4 columns - 1/3', 'js_composer')    => '1/3',
          __('5 columns - 5/12', 'js_composer')   => '5/12',
          __('6 columns - 1/2', 'js_composer')    => '1/2',
          __('7 columns - 7/12', 'js_composer')   => '7/12',
          __('8 columns - 2/3', 'js_composer')    => '2/3',
          __('9 columns - 3/4', 'js_composer')    => '3/4',
          __('10 columns - 5/6', 'js_composer')   => '5/6',
          __('11 columns - 11/12', 'js_composer') => '11/12',
          __('12 columns - 1/1', 'js_composer')   => '1/1'
        ),
        'description'   => __( 'Select column width.', 'js_composer' ),
        'std'           => '1/1'
      ),
      array(
        'type'          => 'column_offset',
        'heading'       => __('Responsiveness', 'js_composer'),
        'param_name'    => 'offset',
        'description'   => __('Adjust column for different screen sizes. Control width, offset and visibility settings.', 'js_composer')
      ),
      array(
        'type'          => 'textfield',
        'heading'       => __('Extra Class', 'js_composer'),
        'param_name'    => 'el_class'
      ),
      array(
        'type'        => 'checkbox',
        'heading'     => __('Add Clear for Specific Devices After Column', 'js_composer'),
        'param_name'  => 'clear',
        'value'       => array(
          '<label for="clear-lg" class="ts-clear-checkbox ts-clear-lg"><span></span></label>' => 'lg',
          '<label for="clear-md" class="ts-clear-checkbox ts-clear-md"><span></span></label>' => 'md',
          '<label for="clear-sm" class="ts-clear-checkbox ts-clear-sm"><span></span></label>' => 'sm',
          '<label for="clear-xs" class="ts-clear-checkbox ts-clear-xs"><span></span></label>' => 'xs'
        ),
        'class'       => '',
        'group'       => __('Clear', 'js_composer')
      ),
    )
  ) );

  vc_map( array(
    'name'              => __('Column', 'js_composer'),
    'base'              => 'vc_column_inner',
    'is_container'      => true,
    'js_view'           => 'VcColumnView',
    'content_element'   => false,
    'controls'          => 'full',
    'allowed_container_element' => false,
    'params'            => array(
      array(
        'type'          => 'dropdown',
        'heading'       => __( 'Width', 'js_composer' ),
        'param_name'    => 'width',
        'value'         => array(
          __('1 column - 1/12', 'js_composer')    => '1/12',
          __('2 columns - 1/6', 'js_composer')    => '1/6',
          __('3 columns - 1/4', 'js_composer')    => '1/4',
          __('4 columns - 1/3', 'js_composer')    => '1/3',
          __('5 columns - 5/12', 'js_composer')   => '5/12',
          __('6 columns - 1/2', 'js_composer')    => '1/2',
          __('7 columns - 7/12', 'js_composer')   => '7/12',
          __('8 columns - 2/3', 'js_composer')    => '2/3',
          __('9 columns - 3/4', 'js_composer')    => '3/4',
          __('10 columns - 5/6', 'js_composer')   => '5/6',
          __('11 columns - 11/12', 'js_composer') => '11/12',
          __('12 columns - 1/1', 'js_composer')   => '1/1'
        ),
        'description'   => __( 'Select column width.', 'js_composer' ),
        'std'           => '1/1'
      ),
      array(
        'type'          => 'column_offset',
        'heading'       => __('Responsiveness', 'js_composer'),
        'param_name'    => 'offset',
        'description'   => __('Adjust column for different screen sizes. Control width, offset and visibility settings.', 'js_composer')
      ),
      array(
        'type'          => 'textfield',
        'heading'       => __('Extra Class', 'js_composer'),
        'param_name'    => 'el_class'
      ),
      array(
        'type'        => 'checkbox',
        'heading'     => __('Add Clear for Specific Devices After Column', 'js_composer'),
        'param_name'  => 'clear',
        'value'       => array(
          '<label for="clear-lg" class="ts-clear-checkbox ts-clear-lg"><span></span></label>' => 'lg',
          '<label for="clear-md" class="ts-clear-checkbox ts-clear-md"><span></span></label>' => 'md',
          '<label for="clear-sm" class="ts-clear-checkbox ts-clear-sm"><span></span></label>' => 'sm',
          '<label for="clear-xs" class="ts-clear-checkbox ts-clear-xs"><span></span></label>' => 'xs'
        ),
        'class'       => '',
        'group'       => __('Clear', 'js_composer')
      ),
    )
  ) );

  /* Text Block
  ---------------------------------------------------------- */
  vc_map( array(
    'name'              => __('Text Block', 'js_composer'),
    'base'              => 'vc_column_text',
    'icon'              => 'dashicons-edit',
    'wrapper_class'     => 'clearfix',
    'category'          => __('Content', 'js_composer'),
    'description'       => __('A block of text with WYSIWYG editor', 'js_composer'),
    'params'            => array(
      array(
        'type'          => 'textarea_html',
        'holder'        => 'div',
        'heading'       => '',
        'param_name'    => 'content',
        'value'         => __('<p>I am text block. Click edit button to change this text.</p>', 'js_composer'),
        'group'         => __( 'Content', 'js_composer' )
      ),
      array(
        'type'          => 'textfield',
        'heading'       => __('Extra Class', 'js_composer'),
        'param_name'    => 'el_class',
        'group'         => __( 'Style', 'js_composer' )
      )
    )
  ) );

  if(function_exists('vc_atm_map')) vc_atm_map();
}

vc_map_default_shortcodes();

function plugin_shortcodes_for_vc($options){

  include_once(ABSPATH . 'wp-admin/includes/plugin.php');
  if (is_plugin_active('contact-form-7/wp-contact-form-7.php')) {

    global $wpdb;
    $cf7 = $wpdb->get_results('SELECT ID, post_title FROM '.$wpdb->posts.' WHERE post_type = "wpcf7_contact_form"');
    
    $contact_forms = array();
    if ($cf7) {
      foreach ( $cf7 as $cform ) {
        $contact_forms[$cform->post_title] = $cform->ID;
      }
    } else {
      $contact_forms['No contact forms found'] = 0;
    }

    array_push($options, array(
      array(
      'base'            => 'contact-form-7',
      'name'            => __('Contact Form 7', 'js_composer'),
      'icon'            => 'fa-envelope-o',
      'category'        => __('Content', 'js_composer'),
      'description'     => __('Place Contact Form7', 'js_composer'),
      'params'          => array(
        array(
          'type'        => 'textfield',
          'heading'     => __('Form Title', 'js_composer'),
          'param_name'  => "title",
          'admin_label' => true,
          'description' => __('What text use as form title. Leave blank if no title is needed.', 'js_composer')
        ),
        array(
          'type'        => 'dropdown',
          'heading'     => __('Contact Form', 'js_composer'),
          'admin_label' => true,
          'param_name'  => 'id',
          'value'       => $contact_forms,
          'description' => __('Choose previously created contact form from the drop down list.', 'js_composer')
        )
      )
    )));
  }

  if (is_plugin_active('revslider/revslider.php')) {

    global $wpdb;
    $rs = $wpdb->get_results('SELECT id, title, alias FROM '.$wpdb->prefix.'revslider_sliders ORDER BY id ASC LIMIT 999');
    $revsliders = array();
    
    if ($rs) {
      foreach ( $rs as $slider ) {
        $revsliders[$slider->title] = $slider->alias;
      }
    } else {
      $revsliders['No sliders found'] = 0;
    }

    array_push($options, array(
      array(
      'base'            => 'rev_slider',
      'name'            => __('Revolution Slider', 'js_composer'),
      'icon'            => 'fa-refresh',
      'category'        => __('Content', 'js_composer'),
      'description'     => __('Place Revolution slider', 'js_composer'),
      'params'          => array(
        array(
          'type'        => 'dropdown',
          'heading'     => __('Revolution Slider', 'js_composer'),
          'param_name'  => 'alias',
          'admin_label' => true,
          'value'       => $revsliders
        )
      )
    )));
  }

  return $options;

}

add_filter( 'vc_maps_for_slupy', 'plugin_shortcodes_for_vc', 12 );