<?php

/*---------------------------------------------
  Columns Layout Options
---------------------------------------------*/
if( !function_exists('columns_layout_options') ) {

function columns_layout_options($args) {

$columns_settings = array(
  array(
    'title'         => __('Columns Layout',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'layouts_sc',
    'shortcode'     => '[ts_section{attr}][ts_row]{content}[/ts_row][/ts_section]',
    'options'       => array(
      array(
        'title'     => __('Columns',TS_TRANSLATE),
        'name'      => 'columns_layouts',
        'id'        => TS_PLUGIN.'columns_layouts',
        'class'     => '',
        'choices'   => array(
            array('label' => '1','value' => '[ts_column size="12"]{column_1}[/ts_column]','src' => TS_PLUGIN_URL . '/images/1.jpg'),
            array('label' => '2','value' => '[ts_column size="6"]{column_1}[/ts_column][ts_column size="6"]{column_2}[/ts_column]','src' => TS_PLUGIN_URL . '/images/2.jpg'),
            array('label' => '3','value' => '[ts_column size="4"]{column_1}[/ts_column][ts_column size="4"]{column_2}[/ts_column][ts_column size="4"]{column_3}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/3.jpg'),
            array('label' => '4','value' => '[ts_column size="3"]{column_1}[/ts_column][ts_column size="3"]{column_2}[/ts_column][ts_column size="3"]{column_3}[/ts_column][ts_column size="3"]{column_4}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/4.jpg'),
            array('label' => '6','value' => '[ts_column size="2"]{column_1}[/ts_column][ts_column size="2"]{column_2}[/ts_column][ts_column size="2"]{column_3}[/ts_column][ts_column size="2"]{column_4}[/ts_column][ts_column size="2"]{column_5}[/ts_column][ts_column size="2"]{column_6}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/6.jpg'),
            array('label' => '3','value' => '[ts_column size="2"]{column_1}[/ts_column][ts_column size="8"]{column_2}[/ts_column][ts_column size="2"]{column_3}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/7.jpg'),
            array('label' => '3','value' => '[ts_column size="2"]{column_1}[/ts_column][ts_column size="2"]{column_2}[/ts_column][ts_column size="8"]{column_3}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/8.jpg'),
            array('label' => '3','value' => '[ts_column size="6"]{column_1}[/ts_column][ts_column size="3"]{column_2}[/ts_column][ts_column size="3"]{column_3}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/9.jpg'),
            array('label' => '3','value' => '[ts_column size="3"]{column_1}[/ts_column][ts_column size="6"]{column_2}[/ts_column][ts_column size="3"]{column_3}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/10.jpg'),
            array('label' => '3','value' => '[ts_column size="3"]{column_1}[/ts_column][ts_column size="3"]{column_2}[/ts_column][ts_column size="6"]{column_3}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/11.jpg'),
            array('label' => '3','value' => '[ts_column size="5"]{column_1}[/ts_column][ts_column size="5"]{column_2}[/ts_column][ts_column size="2"]{column_3}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/12.jpg'),
            array('label' => '3','value' => '[ts_column size="2"]{column_1}[/ts_column][ts_column size="5"]{column_2}[/ts_column][ts_column size="5"]{column_3}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/13.jpg'),
            array('label' => '4','value' => '[ts_column size="6"]{column_1}[/ts_column][ts_column size="2"]{column_2}[/ts_column][ts_column size="2"]{column_3}[/ts_column][ts_column size="2"]{column_4}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/14.jpg'),
            array('label' => '4','value' => '[ts_column size="2"]{column_1}[/ts_column][ts_column size="2"]{column_2}[/ts_column][ts_column size="2"]{column_3}[/ts_column][ts_column size="6"]{column_4}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/15.jpg'),
            array('label' => '5','value' => '[ts_column size="4"]{column_1}[/ts_column][ts_column size="2"]{column_2}[/ts_column][ts_column size="2"]{column_3}[/ts_column][ts_column size="2"]{column_4}[/ts_column][ts_column size="2"]{column_5}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/16.jpg'),
            array('label' => '5','value' => '[ts_column size="2"]{column_1}[/ts_column][ts_column size="2"]{column_2}[/ts_column][ts_column size="4"]{column_3}[/ts_column][ts_column size="2"]{column_4}[/ts_column][ts_column size="2"]{column_5}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/17.jpg'),
            array('label' => '5','value' => '[ts_column size="2"]{column_1}[/ts_column][ts_column size="2"]{column_2}[/ts_column][ts_column size="2"]{column_3}[/ts_column][ts_column size="2"]{column_4}[/ts_column][ts_column size="4"]{column_5}[/ts_column]','src'  => TS_PLUGIN_URL . '/images/18.jpg')
        ),
        'mode'      => 'content',
        'value'     => '[ts_column size="12"]{column_1}[/ts_column]',
        'type'      => 'radio-image'
      ),
      array(
        'title'     => __('Content',TS_TRANSLATE),
        'name'      => 'column_1',
        'id'        => TS_PLUGIN.'spe_content',
        'rows'      => '5',
        'class'     => '',
        'mode'      => 'fake',
        'value'     => '1',
        'type'      => 'textarea'
      )
    )
  ));

  return array_merge($args,$columns_settings);

}

}

/*---------------------------------------------
  Other Shortcodes Options
---------------------------------------------*/
if( !function_exists('themesama_options_values') ) {

function themesama_options_values($args){

  $ts_shortcode_colors = array(
    array(
      'label' => __('Default',TS_TRANSLATE),
      'value' => ''
    ),
    array(
      'label' => __('Dark Blue',TS_TRANSLATE),
      'value' => 'darkblue'
    ),
    array(
      'label' => __('Ocean Blue',TS_TRANSLATE),
      'value' => 'blue'
    ),
    array(
      'label' => __('Green',TS_TRANSLATE),
      'value' => 'green'
    ),
    array(
      'label' => __('Orange',TS_TRANSLATE),
      'value' => 'orange'
    ),
    array(
      'label' => __('Yellow',TS_TRANSLATE),
      'value' => 'yellow'
    ),
    array(
      'label' => __('Custom',TS_TRANSLATE),
      'value' => 'custom'
    )
  );

  $ts_shortcode_colors3 = array(
    array(
      'label' => __('Default',TS_TRANSLATE),
      'value' => ''
    ),
    array(
      'label' => __('Dark Blue',TS_TRANSLATE),
      'value' => 'darkblue'
    ),
    array(
      'label' => __('Ocean Blue',TS_TRANSLATE),
      'value' => 'blue'
    ),
    array(
      'label' => __('Green',TS_TRANSLATE),
      'value' => 'green'
    ),
    array(
      'label' => __('Orange',TS_TRANSLATE),
      'value' => 'orange'
    ),
    array(
      'label' => __('Yellow',TS_TRANSLATE),
      'value' => 'yellow'
    ),
    array(
      'label' => __('White',TS_TRANSLATE),
      'value' => 'white'
    ),
    array(
      'label' => __('Custom',TS_TRANSLATE),
      'value' => 'custom'
    )
  );

  $ts_shortcode_colors_2 = $ts_shortcode_colors;
  array_pop($ts_shortcode_colors_2);

  $ts_shortcode_target = array(
    array(
      'label' => '',
      'value' => ''
    ),
    array(
      'label' => '_blank',
      'value' => '_blank'
    ),
    array(
      'label' => '_self',
      'value' => '_self'
    ),
    array(
      'label' => '_parent',
      'value' => '_parent'
    ),
    array(
      'label' => '_top',
      'value' => '_top'
    )
  );
  
$themesama_settings = array(
  array(
    'title'         => __('Button',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'button_sc',
    'shortcode'     => '[ts_button{attr}]{content}[/ts_button]',
    'options'       => array(
      array(
        'title'     => __('Title',TS_TRANSLATE),
        'name'      => 'title',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('URL',TS_TRANSLATE),
        'name'      => 'url',
        'id'        => '',
        'dependid'  => 'button_sc_url',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Target',TS_TRANSLATE),
        'name'      => 'target',
        'id'        => '',
        'class'     => '',
        'choices'   => $ts_shortcode_target,
        'value'     => '',
        'type'      => 'select',
        'depends'   => '!button_sc_url'
      ),
      array(
        'title'     => __('Size',TS_TRANSLATE),
        'name'      => 'size',
        'id'        => '',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => __('Small',TS_TRANSLATE),
            'value' => 'small'
          ),
          array(
            'label' => __('Medium',TS_TRANSLATE),
            'value' => 'medium'
          ),
          array(
            'label' => __('Large',TS_TRANSLATE),
            'value' => 'large'
          ),
          array(
            'label' => __('X-Large',TS_TRANSLATE),
            'value' => 'xlarge'
          )
        ),
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Icon',TS_TRANSLATE),
        'name'      => 'controls',
        'id'        => '',
        'dependid'  => 'button_sc_icon',
        'class'     => '',
        'value'     => 'off',
        'mode'      => 'fake',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Choose a Icon',TS_TRANSLATE),
        'name'      => 'icon',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'toggle'    => 'hide',
        'type'      => 'iconbox',
        'depends'   => 'button_sc_icon:on'
      ),
      array(
        'title'     => __('Icon Position',TS_TRANSLATE),
        'name'      => 'icon_pos',
        'id'        => '',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => __('Left',TS_TRANSLATE),
            'value' => 'left'
          ),
          array(
            'label' => __('Right',TS_TRANSLATE),
            'value' => 'right'
          ),
          array(
            'label' => __('Top',TS_TRANSLATE),
            'value' => 'top'
          ),
          array(
            'label' => __('Bottom',TS_TRANSLATE),
            'value' => 'bottom'
          )
          
        ),
        'value'     => '',
        'type'      => 'select',
        'depends'   => 'button_sc_icon:on'
      ),
      array(
        'title'     => __('Show Icon with Hover',TS_TRANSLATE),
        'name'      => 'hover_effect',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => 'button_sc_icon:on'
      ),
      array(
        'title'     => __('Color',TS_TRANSLATE),
        'name'      => 'color',
        'id'        => '',
        'dependid'  => 'button_sc_color',
        'class'     => '',
        'choices'   => $ts_shortcode_colors,
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Color',TS_TRANSLATE),
        'name'      => 'bgcolor',
        'id'        => '',
        'class'     => '',
        'color'     => '#dd3333',
        'value'     => '#dd3333',
        'type'      => 'colorpicker',
        'depends'   => 'button_sc_color:custom'
      ),
      array(
        'title'     => __('Color (Hover)',TS_TRANSLATE),
        'name'      => 'bgcolorhover',
        'id'        => '',
        'class'     => '',
        'color'     => '#dd3333',
        'value'     => '#dd3333',
        'type'      => 'colorpicker',
        'depends'   => 'button_sc_color:custom'
      ),
      array(
        'title'     => __('Align',TS_TRANSLATE),
        'name'      => 'align',
        'id'        => '',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => '',
            'value' => ''
          ),
          array(
            'label' => __('Right',TS_TRANSLATE),
            'value' => 'right'
          ),
          array(
            'label' => __('Center',TS_TRANSLATE),
            'value' => 'center'
          ),
          array(
            'label' => __('Left',TS_TRANSLATE),
            'value' => 'left'
          )
          
        ),
        'value'     => '',
        'type'      => 'select'
      )
    )

  ),
  array(
    'title'         => __('Buttons Set',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'buttons_sc',
    'shortcode'     => '[ts_buttonset{attr}]',
    'options'       => array(
      array(
        'title'     => __('Title - Left Button',TS_TRANSLATE),
        'name'      => 'title_left',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('URL - Left Button',TS_TRANSLATE),
        'name'      => 'url',
        'id'        => '',
        'dependid'  => 'buttons_sc_url',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Target - Left Button',TS_TRANSLATE),
        'name'      => 'target',
        'id'        => '',
        'class'     => '',
        'choices'   => $ts_shortcode_target,
        'value'     => '',
        'type'      => 'select',
        'depends'   => '!buttons_sc_url'
      ),
      array(
        'title'     => __('Title - Right Button',TS_TRANSLATE),
        'name'      => 'title_right',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('URL - Right Button',TS_TRANSLATE),
        'name'      => 'url2',
        'id'        => '',
        'dependid'  => 'buttons_sc_url2',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Target - Right Button',TS_TRANSLATE),
        'name'      => 'target2',
        'id'        => '',
        'class'     => '',
        'choices'   => $ts_shortcode_target,
        'value'     => '',
        'type'      => 'select',
        'depends'   => '!buttons_sc_url2'
      ),
      array(
        'title'     => __('Title - Button Center',TS_TRANSLATE),
        'name'      => 'center_text',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Color',TS_TRANSLATE),
        'name'      => 'color',
        'id'        => '',
        'class'     => '',
        'choices'   => $ts_shortcode_colors_2,
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Align',TS_TRANSLATE),
        'name'      => 'align',
        'id'        => '',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => '',
            'value' => ''
          ),
          array(
            'label' => __('Right',TS_TRANSLATE),
            'value' => 'right'
          ),
          array(
            'label' => __('Center',TS_TRANSLATE),
            'value' => 'center'
          ),
          array(
            'label' => __('Left',TS_TRANSLATE),
            'value' => 'left'
          )
          
        ),
        'value'     => '',
        'type'      => 'select'
      )
    )
  ),
  array(
    'title'         => __('Blockquote & InfoBox',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'blockquote_sc',
    'shortcode'     => '[ts_blockquote{attr}]{content}[/ts_blockquote]',
    'options'       => array(
      array(
        'title'     => __('Quote Icon',TS_TRANSLATE),
        'name'      => 'quote_icon',
        'id'        => '',
        'class'     => '',
        'value'     => 'off',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Line Type',TS_TRANSLATE),
        'name'      => 'horizontal_line',
        'id'        => '',
        'class'     => 'big_switch',
        'value'     => 'off',
        'text'      => __('Horizontal',TS_TRANSLATE).':'.__('Vertical',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Color Options',TS_TRANSLATE),
        'name'      => 'color',
        'id'        => '',
        'dependid'  => 'blockquote_sc_color',
        'class'     => '',
        'choices'   => $ts_shortcode_colors,
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Custom Color',TS_TRANSLATE),
        'name'      => 'custom_color',
        'id'        => '',
        'class'     => '',
        'color'     => '#dd3333',
        'value'     => '#dd3333',
        'type'      => 'colorpicker',
        'depends'   => 'blockquote_sc_color:custom'
      ),
      array(
        'title' => __('Author',TS_TRANSLATE),
        'name'  => 'author_name',
        'id'    => '',
        'class' => '',
        'value' => '',
        'type'  => 'text'
      ),
      array(
        'title' => __('Job',TS_TRANSLATE),
        'name'  => 'author_job',
        'id'    => '',
        'class' => '',
        'value' => '',
        'type'  => 'text'
      ),
      array(
        'title' => __('Content',TS_TRANSLATE),
        'name'  => 'content',
        'id'    => '',
        'rows'  => '5',
        'class' => '',
        'mode'  => 'content',
        'value' => '',
        'type'  => 'textarea'
      )
    )
  ),
  array(
    'title'         => __('Highlight',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'highlight_sc',
    'shortcode'     => '[ts_highlight{attr}]{content}[/ts_highlight]',
    'options'       => array(
      array(
        'title'     => __('Color',TS_TRANSLATE),
        'name'      => 'color',
        'id'        => '',
        'dependid'  => 'highlight_sc_color',
        'class'     => '',
        'choices'   => $ts_shortcode_colors,
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Text Color',TS_TRANSLATE),
        'name'      => 'custom_textcolor',
        'id'        => '',
        'class'     => '',
        'color'     => '#ffffff',
        'value'     => '#ffffff',
        'type'      => 'colorpicker',
        'depends'   => 'highlight_sc_color:custom'
      ),
      array(
        'title'     => __('BG Color',TS_TRANSLATE),
        'name'      => 'custom_bgcolor',
        'id'        => '',
        'class'     => '',
        'color'     => '#dd3333',
        'value'     => '#dd3333',
        'type'      => 'colorpicker',
        'depends'   => 'highlight_sc_color:custom'
      ),
      array(
        'title'     => __('Text',TS_TRANSLATE),
        'name'      => '',
        'id'        => '',
        'class'     => '',
        'mode'      => 'content',
        'value'     => '',
        'type'      => 'text'
      )
    )
  ),
  array(
    'title'         => __('List Styles',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'liststyle_sc',
    'shortcode'     => '[ts_list{attr}]{content}[/ts_list]',
    'options'       => array(
      array(
        'title'     => __('Type',TS_TRANSLATE),
        'name'      => 'type',
        'id'        => '',
        'dependid'  => 'liststyle_sc_type',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => __('Circle',TS_TRANSLATE),
            'value' => 'circle'
          ),
          array(
            'label' => __('Square',TS_TRANSLATE),
            'value' => 'square'
          ),
          array(
            'label' => __('Roman',TS_TRANSLATE),
            'value' => 'roman'
          ),
          array(
            'label' => __('Latin',TS_TRANSLATE),
            'value' => 'latin'
          ),
          array(
            'label' => __('Katakana',TS_TRANSLATE),
            'value' => 'katakana'
          ),
          array(
            'label' => __('Custom',TS_TRANSLATE),
            'value' => 'custom'
          )
        ),
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Icon',TS_TRANSLATE),
        'name'      => 'icon',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'toggle'    => 'hide',
        'type'      => 'iconbox',
        'depends'   => 'liststyle_sc_type:custom'
      ),
      array(
        'title'     => __('Content',TS_TRANSLATE),
        'name'      => 'content',
        'id'        => '',
        'rows'      => '12',
        'class'     => '',
        'mode'      => 'content',
        'value'     => '<ul>
 <li>List</li>
 <li>List</li>
 <li>List</li>
</ul>',
        'type'      => 'textarea'
      )
    )
  ),
  array(
    'title'         => __('Feature Box',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'featurebox_sc',
    'shortcode'     => '[ts_featurebox{attr}]{content}[/ts_featurebox]',
    'options'       => array(
      array(
        'title'     => __('Images',TS_TRANSLATE),
        'name'      => 'id',
        'dependid'  => 'featurebox_sc_id',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'live'      => 'true',
        'multi'     => 'true',
        'type'      => 'upload'
      ),
      array(
        'title'     => __('Icon',TS_TRANSLATE),
        'name'      => 'icon',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'toggle'    => 'hide',
        'type'      => 'iconbox'
      ),
      array(
        'title'     => __('Heading Size',TS_TRANSLATE),
        'name'      => 'h_size',
        'id'        => '',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => 'H1',
            'value' => '1'
          ),
          array(
            'label' => 'H2',
            'value' => '2'
          ),
          array(
            'label' => 'H3',
            'value' => '3'
          ),
          array(
            'label' => 'H4',
            'value' => '4'
          ),
          array(
            'label' => 'H5',
            'value' => '5'
          ),
          array(
            'label' => 'H6',
            'value' => '6'
          )
        ),
        'value'     => '3',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Heading',TS_TRANSLATE),
        'name'      => 'heading',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Content',TS_TRANSLATE),
        'name'      => 'content',
        'id'        => '',
        'rows'      => '5',
        'class'     => '',
        'mode'      => 'content',
        'value'     => '',
        'type'      => 'textarea'
      ),
      array(
        'title'     => __('Open With',TS_TRANSLATE),
        'name'      => 'click_open',
        'dependid'  => 'featurebox_sc_click_open',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('Click',TS_TRANSLATE).':'.__('Hover',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('URL',TS_TRANSLATE),
        'name'      => 'url',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text',
        'depends'   => 'featurebox_sc_click_open:off'
      ),
      array(
        'title'     => __('Target',TS_TRANSLATE),
        'name'      => 'target',
        'id'        => '',
        'class'     => '',
        'choices'   => $ts_shortcode_target,
        'value'     => '',
        'type'      => 'select',
        'depends'   => 'featurebox_sc_click_open:off'
      ),
      array(
        'title'       => __('Slider Config',TS_TRANSLATE),
        'description' => __('If you use a few images for a Feature Box, you can edit slider config.',TS_TRANSLATE),
        'type'        => 'textblock',
        'depends'     => '!featurebox_sc_id'
      ),
      array(
        'title'     => __('Auto Play',TS_TRANSLATE),
        'name'      => 'autoplay',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => '!featurebox_sc_id'
      ),
      array(
        'title'     => __('Stop on Hover',TS_TRANSLATE),
        'name'      => 'stop_hover',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => '!featurebox_sc_id'
      ),
      array(
        'title'     => __('Navigation',TS_TRANSLATE),
        'name'      => 'navigation',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => '!featurebox_sc_id'
      ),
      array(
        'title'     => __('Effect',TS_TRANSLATE),
        'name'      => 'fade_effect',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('FADE',TS_TRANSLATE).':'.__('SCROLL',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => '!featurebox_sc_id'
      ),
      array(
        'title'     => __('Touch Drag',TS_TRANSLATE),
        'name'      => 'touch_drag',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => '!featurebox_sc_id'
      ),
      array(
        'title'         => __('Slide Duration Time (second)',TS_TRANSLATE),
        'name'          => 'duration_time',
        'id'            => '',
        'class'         => '',
        'value'         => '4',
        'min_max_step'  => '2,30,1',
        'type'          => 'numeric-slider',
        'depends'       => '!featurebox_sc_id'
      )
    )
  ),
  array(
    'title'         => __('Team Member',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'team_sc',
    'shortcode'     => '[ts_team{attr}]{content}[/ts_team]',
    'options'       => array(
      array(
        'title'     => __('Images',TS_TRANSLATE),
        'name'      => 'id',
        'dependid'  => 'teammember_sc_id',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'live'      => 'true',
        'multi'     => 'true',
        'type'      => 'upload'
      ),
      array(
        'title'     => __('Heading Size',TS_TRANSLATE),
        'name'      => 'h_size',
        'id'        => '',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => 'H1',
            'value' => '1'
          ),
          array(
            'label' => 'H2',
            'value' => '2'
          ),
          array(
            'label' => 'H3',
            'value' => '3'
          ),
          array(
            'label' => 'H4',
            'value' => '4'
          ),
          array(
            'label' => 'H5',
            'value' => '5'
          ),
          array(
            'label' => 'H6',
            'value' => '6'
          )
        ),
        'value'     => '3',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Name',TS_TRANSLATE),
        'name'      => 'name',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Job',TS_TRANSLATE),
        'name'      => 'job',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Content',TS_TRANSLATE),
        'name'      => 'content',
        'id'        => '',
        'rows'      => '5',
        'class'     => '',
        'mode'      => 'content',
        'value'     => '',
        'type'      => 'textarea'
      ),
      array(
        'title'       => __('Slider Config',TS_TRANSLATE),
        'description' => __('If you use a few images for a team member, you can edit slider config.',TS_TRANSLATE),
        'type'        => 'textblock',
        'depends'     => '!teammember_sc_id'
      ),
      array(
        'title'     => __('Auto Play',TS_TRANSLATE),
        'name'      => 'autoplay',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => '!teammember_sc_id'
      ),
      array(
        'title'     => __('Stop on Hover',TS_TRANSLATE),
        'name'      => 'stop_hover',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => '!teammember_sc_id'
      ),
      array(
        'title'     => __('Navigation',TS_TRANSLATE),
        'name'      => 'navigation',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => '!teammember_sc_id'
      ),
      array(
        'title'     => __('Effect',TS_TRANSLATE),
        'name'      => 'fade_effect',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('FADE',TS_TRANSLATE).':'.__('SCROLL',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => '!teammember_sc_id'
      ),
      array(
        'title'     => __('Touch Drag',TS_TRANSLATE),
        'name'      => 'touch_drag',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => '!teammember_sc_id'
      ),
      array(
        'title'         => __('Slide Duration Time (second)',TS_TRANSLATE),
        'name'          => 'duration_time',
        'id'            => '',
        'class'         => '',
        'value'         => '4',
        'min_max_step'  => '2,30,1',
        'type'          => 'numeric-slider',
        'depends'       => '!teammember_sc_id'
      )
    )
  ),
  array(
    'title'         => __('Icon & Heading',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'icon_sc',
    'shortcode'     => '[ts_icon{attr}]',
    'options'       => array(
      array(
        'title'     => __('Icon',TS_TRANSLATE),
        'name'      => 'icon',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'toggle'    => '',
        'type'      => 'iconbox'
      ),
      array(
        'title'     => __('Size',TS_TRANSLATE),
        'name'      => 'size',
        'id'        => '',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => __('Small',TS_TRANSLATE),
            'value' => 'small'
          ),
          array(
            'label' => __('Medium',TS_TRANSLATE),
            'value' => 'medium'
          ),
          array(
            'label' => __('Large',TS_TRANSLATE),
            'value' => 'large'
          ),
          array(
            'label' => __('X-Large',TS_TRANSLATE),
            'value' => 'xlarge'
          ),
          array(
            'label' => __('XX-Large',TS_TRANSLATE),
            'value' => 'xxlarge'
          )
        ),
        'value'     => '',
        'type'      => 'select',
        'depends'   => 'icon_sc_heading'
      ),
      array(
        'title'     => __('Heading Size',TS_TRANSLATE),
        'name'      => 'h_size',
        'id'        => '',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => 'H1',
            'value' => '1'
          ),
          array(
            'label' => 'H2',
            'value' => '2'
          ),
          array(
            'label' => 'H3',
            'value' => '3'
          ),
          array(
            'label' => 'H4',
            'value' => '4'
          ),
          array(
            'label' => 'H5',
            'value' => '5'
          ),
          array(
            'label' => 'H6',
            'value' => '6'
          )
        ),
        'value'     => '3',
        'type'      => 'select',
        'depends'   => '!icon_sc_heading'
      ),
      array(
        'title'     => __('Heading',TS_TRANSLATE),
        'name'      => 'heading',
        'id'        => '',
        'dependid'  => 'icon_sc_heading',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      )
    )
  ),
  array(
    'title'         => __('Dropcap & Iconbox',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'dropcap_sc',
    'shortcode'     => '[ts_dropcap{attr}]',
    'options'       => array(
      array(
        'title'     => __('Icon',TS_TRANSLATE),
        'name'      => 'icon',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'toggle'    => 'hide',
        'type'      => 'iconbox'
      ),
      array(
        'title'     => __('Text',TS_TRANSLATE),
        'name'      => 'text',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Model',TS_TRANSLATE),
        'name'      => 'bg',
        'id'        => '',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => __('Square BG',TS_TRANSLATE),
            'value' => 'square'
          ),
          array(
            'label' => __('Circle BG',TS_TRANSLATE),
            'value' => 'circle'
          ),
          array(
            'label' => __('Transoarent BG',TS_TRANSLATE),
            'value' => 'transparent'
          )
        ),
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Color Options',TS_TRANSLATE),
        'name'      => 'color',
        'id'        => '',
        'dependid'  => 'blockquote_sc_color',
        'class'     => '',
        'choices'   => $ts_shortcode_colors3,
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Custom Color',TS_TRANSLATE),
        'name'      => 'custom_color',
        'id'        => '',
        'class'     => '',
        'color'     => '#dd3333',
        'value'     => '#dd3333',
        'type'      => 'colorpicker',
        'depends'   => 'blockquote_sc_color:custom'
      ),
      array(
        'title'     => __('Dropcap Position',TS_TRANSLATE),
        'name'      => 'left_dropcap',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('Left',TS_TRANSLATE).':'.__('Right',TS_TRANSLATE),
        'type'      => 'switch'
      )
    )
  ),
  array(
    'title'         => __('Tabs',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'tabs_sc',
    'shortcode'     => '[ts_tabs{attr}]{content}[/ts_tabs]',
    'options'       => array(
      array(
        'title'     => __('Tab Buttons',TS_TRANSLATE),
        'name'      => 'horizontal_buttons',
        'id'        => '',
        'class'     => 'big_switch',
        'value'     => 'on',
        'text'      => __('Horizontal',TS_TRANSLATE).':'.__('Vertical',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Buttons Position',TS_TRANSLATE),
        'name'      => 'left_buttons',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('Left',TS_TRANSLATE).':'.__('Right',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Open With',TS_TRANSLATE),
        'name'      => 'click_open',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('Click',TS_TRANSLATE).':'.__('Hover',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Color Options',TS_TRANSLATE),
        'name'      => 'color',
        'id'        => '',
        'dependid'  => 'tabs_sc_color',
        'class'     => '',
        'choices'   => $ts_shortcode_colors,
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Custom Color',TS_TRANSLATE),
        'name'      => 'custom_color',
        'id'        => '',
        'class'     => '',
        'color'     => '#dd3333',
        'value'     => '#dd3333',
        'type'      => 'colorpicker',
        'depends'   => 'tabs_sc_color:custom'
      ),
      array(
        'title'         => __('Tab Section',TS_TRANSLATE),
        'shortcode'     => '[ts_tab{attr}]{content}[/ts_tab]',
        'addbutton'     => __('Add New',TS_TRANSLATE),
        'removebutton'  => __('Remove This',TS_TRANSLATE),
        'options'       => array(
          array(
            'title' => __('Icon',TS_TRANSLATE),
            'name'  => 'icon',
            'id'    => '',
            'class' => '',
            'value' => '',
            'toggle'=> 'hide',
            'type'  => 'iconbox'
          ),
          array(
            'title' => __('Title',TS_TRANSLATE),
            'name'  => 'title',
            'id'    => '',
            'class' => '',
            'value' => '',
            'type'  => 'text'
          ),
          array(
            'title' => __('Content',TS_TRANSLATE),
            'name'  => 'content',
            'id'    => '',
            'rows'  => '5',
            'class' => '',
            'mode'  => 'content',
            'value' => '',
            'type'  => 'textarea'
          )
        ),
        'type'      => 'group-content'
      )
    )
  ),
  array(
    'title'         => __('Accordion & Toggle',TS_TRANSLATE),
    'id'          => TS_PLUGIN.'accordions_sc',
    'shortcode'       => '[ts_accordions{attr}]{content}[/ts_accordions]',
    'options'       => array(
      array(
        'title'     => __('Collapsible',TS_TRANSLATE),
        'name'      => 'collapsible',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Open With',TS_TRANSLATE),
        'name'      => 'click_open',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('Click',TS_TRANSLATE).':'.__('Hover',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Color Options',TS_TRANSLATE),
        'name'      => 'color',
        'id'        => '',
        'dependid'  => 'accordions_sc_color',
        'class'     => '',
        'choices'   => $ts_shortcode_colors,
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Custom Color',TS_TRANSLATE),
        'name'      => 'custom_color',
        'id'        => '',
        'class'     => '',
        'color'     => '#dd3333',
        'value'     => '#dd3333',
        'type'      => 'colorpicker',
        'depends'   => 'accordions_sc_color:custom'
      ),
      array(
        'title'         => __('Accordion Section',TS_TRANSLATE),
        'shortcode'     => '[ts_accordion{attr}]{content}[/ts_accordion]',
        'addbutton'     => __('Add New Section',TS_TRANSLATE),
        'removebutton'  => __('Remove This Section',TS_TRANSLATE),
        'options'       => array(
          array(
            'title' => __('Icon',TS_TRANSLATE),
            'name'  => 'icon',
            'id'    => '',
            'class' => '',
            'value' => '',
            'toggle'=> 'hide',
            'type'  => 'iconbox'
          ),
          array(
            'title' => __('Title',TS_TRANSLATE),
            'name'  => 'title',
            'id'    => '',
            'class' => '',
            'value' => '',
            'type'  => 'text'
          ),
          array(
            'title' => __('Content',TS_TRANSLATE),
            'name'  => 'content',
            'id'    => '',
            'rows'  => '5',
            'class' => '',
            'mode'  => 'content',
            'value' => '',
            'type'  => 'textarea'
          ),
          array(
            'title' => __('Activated',TS_TRANSLATE),
            'name'  => 'activated',
            'id'    => '',
            'class' => '',
            'value' => 'off',
            'text'  => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'  => 'switch'
          )
        ),
        'type'      => 'group-content'
      )
    )
  ),
  array(
    'title'         => __('Alert Boxes',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'alertboxes_sc',
    'shortcode'     => '[ts_alertbox{attr}]{content}[/ts_alertbox]',
    'options'       => array(
      array(
        'title'     => __('Model',TS_TRANSLATE),
        'name'      => 'model',
        'id'        => '',
        'class'     => '',
        'dependid'  => 'alertboxes_sc_model',
        'choices'   => array(
          array(
            'label' => __('Success',TS_TRANSLATE),
            'value' => 'success'
          ),
          array(
            'label' => __('Info',TS_TRANSLATE),
            'value' => 'info'
          ),
          array(
            'label' => __('Notice',TS_TRANSLATE),
            'value' => 'notice'
          ),
          array(
            'label' => __('Error',TS_TRANSLATE),
            'value' => 'error'
          ),
          array(
            'label' => __('Custom',TS_TRANSLATE),
            'value' => 'custom'
          )
        ),
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Icon',TS_TRANSLATE),
        'name'      => 'icon',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'toggle'    => 'hide',
        'type'      => 'iconbox',
        'depends'   => 'alertboxes_sc_model:custom'
      ),
      array(
        'title'     => __('BG Color',TS_TRANSLATE),
        'name'      => 'bg_color',
        'id'        => '',
        'class'     => '',
        'color'     => '#dd3333',
        'value'     => '#dd3333',
        'type'      => 'colorpicker',
        'depends'   => 'alertboxes_sc_model:custom'
      ),
      array(
        'title'     => __('Content',TS_TRANSLATE),
        'name'      => 'content',
        'id'        => '',
        'rows'      => '5',
        'class'     => '',
        'mode'      => 'content',
        'value'     => '',
        'type'      => 'textarea'
      )
    )
  ),
  array(
    'title'         => __('Responsive Slider',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'slider_sc',
    'shortcode'     => '[ts_slider{attr}]{content}[/ts_slider]',
    'options'       => array(
      array(
        'title'     => __('Auto Play',TS_TRANSLATE),
        'name'      => 'autoplay',
        'id'        => '',
        'dependid'  => 'slider_sc_autoplay',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Stop on Hover',TS_TRANSLATE),
        'name'      => 'stop_hover',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => 'slider_sc_autoplay:on'
      ),
      array(
        'title'     => __('Navigation',TS_TRANSLATE),
        'name'      => 'navigation',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Pagination',TS_TRANSLATE),
        'name'      => 'pagination',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Effect',TS_TRANSLATE),
        'name'      => 'fade_effect',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('FADE',TS_TRANSLATE).':'.__('SCROLL',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Touch Drag',TS_TRANSLATE),
        'name'      => 'touch_drag',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Auto Height',TS_TRANSLATE),
        'name'      => 'auto_height',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'         => __('Slide Duration Time (second)',TS_TRANSLATE),
        'name'          => 'duration_time',
        'id'            => '',
        'class'         => '',
        'value'         => '4',
        'min_max_step'  => '2,30,1',
        'type'          => 'numeric-slider',
        'depends'       => 'slider_sc_autoplay:on'
      ),
      array(
        'title'         => __('Slider Item',TS_TRANSLATE),
        'shortcode'     => '[ts_slideritem{attr}]{content}[/ts_slideritem]',
        'addbutton'     => __('Add New',TS_TRANSLATE),
        'removebutton'  => __('Remove This',TS_TRANSLATE),
        'options'       => array(
          array(
            'title' => __('Image',TS_TRANSLATE),
            'name'  => 'src',
            'id'    => '',
            'class' => '',
            'value' => '',
            'live'  => '',
            'type'  => 'upload'
          ),
          array(
            'title' => __('Title',TS_TRANSLATE),
            'name'  => 'title',
            'id'    => '',
            'class' => '',
            'value' => '',
            'type'  => 'text'
          ),
          array(
            'title' => __('Description',TS_TRANSLATE),
            'name'  => 'content',
            'id'    => '',
            'rows'  => '5',
            'class' => '',
            'mode'  => 'content',
            'value' => '',
            'type'  => 'textarea'
          ),
          array(
            'title'     => __('Description Vertical Position',TS_TRANSLATE),
            'name'      => 'v_pos',
            'id'        => '',
            'class'     => '',
            'choices'   => array(
              array(
                'label' => __('Top',TS_TRANSLATE),
                'value' => 'top'
              ),
              array(
                'label' => __('Bottom',TS_TRANSLATE),
                'value' => 'bottom'
              )
            ),
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'     => __('Description Horizontal Position',TS_TRANSLATE),
            'name'      => 'h_pos',
            'id'        => '',
            'class'     => '',
            'choices'   => array(
              array(
                'label' => __('Left',TS_TRANSLATE),
                'value' => 'left'
              ),
              array(
                'label' => __('Right',TS_TRANSLATE),
                'value' => 'right'
              ),
              array(
                'label' => __('Center',TS_TRANSLATE),
                'value' => 'center'
              )
            ),
            'value'     => '',
            'type'      => 'select'
          ),
        ),
        'type'          => 'group-content'
      )
    )
  ),
  array(
    'title'         => __('Testimonials',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'testimonials_sc',
    'shortcode'     => '[ts_testimonials{attr}]{content}[/ts_testimonials]',
    'options'       => array(
      array(
        'title'     => __('Auto Play',TS_TRANSLATE),
        'name'      => 'autoplay',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Stop on Hover',TS_TRANSLATE),
        'name'      => 'stop_hover',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Navigation',TS_TRANSLATE),
        'name'      => 'navigation',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Effect',TS_TRANSLATE),
        'name'      => 'fade_effect',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('FADE',TS_TRANSLATE).':'.__('SCROLL',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Touch Drag',TS_TRANSLATE),
        'name'      => 'touch_drag',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'         => __('Slide Duration Time (second)',TS_TRANSLATE),
        'name'          => 'duration_time',
        'id'            => '',
        'class'         => '',
        'value'         => '4',
        'min_max_step'  => '2,30,1',
        'type'          => 'numeric-slider'
      ),
      array(
        'title'     => __('Model',TS_TRANSLATE),
        'name'      => 'model',
        'id'        => '',
        'dependid'  => 'accordions_sc_color',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => __('Big Image',TS_TRANSLATE),
            'value' => 'big-testimonial'
          ),
          array(
            'label' => __('Standard',TS_TRANSLATE),
            'value' => 'standard'
          )
        ),
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'         => __('Testimonial',TS_TRANSLATE),
        'shortcode'     => '[ts_testimonial{attr}]{content}[/ts_testimonial]',
        'addbutton'     => __('Add New',TS_TRANSLATE),
        'removebutton'  => __('Remove This',TS_TRANSLATE),
        'options'       => array(
          array(
            'title' => __('Name',TS_TRANSLATE),
            'name'  => 'client_name',
            'id'    => '',
            'class' => '',
            'value' => '',
            'type'  => 'text'
          ),
          array(
            'title' => __('Job',TS_TRANSLATE),
            'name'  => 'client_job',
            'id'    => '',
            'class' => '',
            'value' => '',
            'type'  => 'text'
          ),
          array(
            'title' => __('Image',TS_TRANSLATE),
            'name'  => 'client_image',
            'id'    => '',
            'class' => '',
            'value' => '',
            'live'  => 'true',
            'type'  => 'upload'
          ),
          array(
            'title' => __('Testimonial Content',TS_TRANSLATE),
            'name'  => 'content',
            'id'    => '',
            'rows'  => '5',
            'class' => '',
            'mode'  => 'content',
            'value' => '',
            'type'  => 'textarea'
          )
        ),
        'type'      => 'group-content'
      )
    )
  ),
  array(
    'title'         => __('Responsive Media',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'rsvideo_sc',
    'shortcode'     => '[ts_media{attr}]{content}[/ts_media]',
    'options'       => array(
      array(
        'title'     => __('Media Type',TS_TRANSLATE),
        'name'      => 'mediatype',
        'id'        => '',
        'dependid'  => 'rsvideo_sc_mediatype',
        'class'     => '',
        'mode'      => 'fake',
        'value'     => 'on',
        'text'      => __('Video',TS_TRANSLATE).':'.__('Image',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Your Image',TS_TRANSLATE),
        'name'      => 'image_src',
        'id'        => '',
        'dependid'  => 'rsvideo_sc_image_src',
        'class'     => '',
        'value'     => '',
        'type'      => 'upload',
        'depends'   => 'rsvideo_sc_mediatype:off'
      ),
      array(
        'title'     => __('URL',TS_TRANSLATE),
        'name'      => 'url',
        'id'        => '',
        'dependid'  => 'rsvideo_sc_url',
        'class'     => '',
        'value'     => '',
        'type'      => 'text',
        'depends'   => 'rsvideo_sc_mediatype:off + !rsvideo_sc_image_src'
      ),
      array(
        'title'     => __('Target',TS_TRANSLATE),
        'name'      => 'target',
        'id'        => '',
        'class'     => '',
        'choices'   => $ts_shortcode_target,
        'value'     => '',
        'type'      => 'select',
        'depends'   => 'rsvideo_sc_mediatype:off + !rsvideo_sc_url'
      ),
      array(
        'title'     => __('Embed Type',TS_TRANSLATE),
        'name'      => 'embedtype',
        'id'        => '',
        'dependid'  => 'rsvideo_sc_embedtype',
        'class'     => '',
        'mode'      => 'fake',
        'value'     => 'on',
        'text'      => __('url',TS_TRANSLATE).':'.__('iframe',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => 'rsvideo_sc_mediatype:on'
      ),
      array(
        'title'     => __('Your Own Video (.mp4)',TS_TRANSLATE),
        'name'      => 'video_mp4',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'filetype'  => 'video',
        'type'      => 'upload',
        'depends'   => 'rsvideo_sc_mediatype:on + rsvideo_sc_embedtype:on'
      ),
      array(
        'title'     => __('Type (.webm)',TS_TRANSLATE),
        'name'      => 'video_webm',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'filetype'  => 'video',
        'type'      => 'upload',
        'depends'   => 'rsvideo_sc_mediatype:on + rsvideo_sc_embedtype:on'
      ),
      array(
        'title'     => __('Type (.ogv)',TS_TRANSLATE),
        'name'      => 'video_ogv',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'filetype'  => 'video',
        'type'      => 'upload',
        'depends'   => 'rsvideo_sc_mediatype:on + rsvideo_sc_embedtype:on'
      ),
      array(
        'title'     => __('Auto Play',TS_TRANSLATE),
        'name'      => 'autoplay',
        'id'        => '',
        'class'     => '',
        'value'     => 'off',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => 'rsvideo_sc_mediatype:on + rsvideo_sc_embedtype:on'
      ),
      array(
        'title'     => __('Muted',TS_TRANSLATE),
        'name'      => 'muted',
        'id'        => '',
        'class'     => '',
        'value'     => 'off',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => 'rsvideo_sc_mediatype:on + rsvideo_sc_embedtype:on'
      ),
      array(
        'title'     => __('Loop',TS_TRANSLATE),
        'name'      => 'loop',
        'id'        => '',
        'class'     => '',
        'value'     => 'off',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => 'rsvideo_sc_mediatype:on + rsvideo_sc_embedtype:on'
      ),
      array(
        'title'     => 'Controls',
        'name'      => 'controls',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => 'rsvideo_sc_mediatype:on + rsvideo_sc_embedtype:on'
      ),
      array(
        'title'     => __('Poster',TS_TRANSLATE),
        'name'      => 'poster',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'upload',
        'depends'   => 'rsvideo_sc_mediatype:on + rsvideo_sc_embedtype:on'
      ),
      array(
        'title'     => __('Iframe Embed Code',TS_TRANSLATE),
        'name'      => 'content',
        'id'        => '',
        'rows'      => '5',
        'class'     => '',
        'mode'      => 'content',
        'value'     => '',
        'type'      => 'textarea',
        'depends'   => 'rsvideo_sc_mediatype:on + rsvideo_sc_embedtype:off'
      )
    )
  ),
  array(
    'title'         => __('Progress Bars',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'bars_sc',
    'shortcode'     => '[ts_bars{attr}]{content}[/ts_bars]',
    'options'       => array(
      array(
        'title'     => __('Model',TS_TRANSLATE),
        'name'      => 'model',
        'id'        => '',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => __('White Label',TS_TRANSLATE),
            'value' => 'white-label'
          ),
          array(
            'label' => __('Standard',TS_TRANSLATE),
            'value' => 'standard'
          ),
          array(
            'label' => __('Thin',TS_TRANSLATE),
            'value' => 'thin'
          )
        ),
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Animated',TS_TRANSLATE),
        'name'      => 'animated',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'         => __('Bars',TS_TRANSLATE),
        'shortcode'     => '[ts_bar{attr}]',
        'addbutton'     => __('Add New',TS_TRANSLATE),
        'removebutton'  => __('Remove This',TS_TRANSLATE),
        'options'       => array(
          array(
            'title'     => __('Title',TS_TRANSLATE),
            'name'      => 'title',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'type'      => 'text'
          ),
          array(
            'title'         => __('Percentage (%)',TS_TRANSLATE),
            'name'          => 'percentage',
            'id'            => '',
            'class'         => '',
            'value'         => '50',
            'min_max_step'  => '0,100,1',
            'type'          => 'numeric-slider'
          ),
          array(
            'title'     => __('Percentage Text',TS_TRANSLATE),
            'name'      => 'percentage_text',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'type'      => 'text'
          ),
          array(
            'title'     => __('Icon',TS_TRANSLATE),
            'name'      => 'icon',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'toggle'    => 'hide',
            'type'      => 'iconbox'
          ),
          array(
            'title'     => __('Color',TS_TRANSLATE),
            'name'      => 'color',
            'id'        => '',
            'class'     => '',
            'choices'   => $ts_shortcode_colors_2,
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'     => __('Custom Color',TS_TRANSLATE),
            'name'      => 'custom_color',
            'id'        => '',
            'class'     => '',
            'color'     => '',
            'value'     => '',
            'type'      => 'colorpicker'
          )
        ),
        'type'      => 'group-content'
      )
    )

  ),
  array(
    'title'         => __('Pie Chart',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'chart_sc',
    'shortcode'     => '[ts_charts{attr}]{content}[/ts_charts]',
    'options'       => array(
      array(
        'title'     => __('Model',TS_TRANSLATE),
        'name'      => 'model',
        'id'        => '',
        'dependid'  => 'chart_sc_model',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => __('Standard',TS_TRANSLATE),
            'value' => 'standard'
          ),
          array(
            'label' => __('Tooltip Label',TS_TRANSLATE),
            'value' => 'tooltip'
          )
        ),
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Tooltip Position',TS_TRANSLATE),
        'name'      => 'tooltip_top',
        'id'        => '',
        'class'     => 'medium_switch',
        'value'     => 'on',
        'text'      => __('Top',TS_TRANSLATE).':'.__('Bottom',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => 'chart_sc_model:tooltip'
      ),
      array(
        'title'     => __('Tooltip Method',TS_TRANSLATE),
        'name'      => 'tooltip_hover',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('Hover',TS_TRANSLATE).':'.__('Click',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => 'chart_sc_model:tooltip'
      ),
      array(
        'title'     => __('Size',TS_TRANSLATE),
        'name'      => 'size',
        'id'        => '',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => __('Small',TS_TRANSLATE),
            'value' => '128'
          ),
          array(
            'label' => __('Medium',TS_TRANSLATE),
            'value' => '196'
          ),
          array(
            'label' => __('Large',TS_TRANSLATE),
            'value' => '256'
          )
        ),
        'value'     => '128',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Animated',TS_TRANSLATE),
        'name'      => 'animated',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'       => __('Charts',TS_TRANSLATE),
        'shortcode'   => '[ts_chart{attr}]',
        'addbutton'   => __('Add New',TS_TRANSLATE),
        'removebutton'=> __('Remove This',TS_TRANSLATE),
        'options'     => array(
          array(
            'title'     => __('Title',TS_TRANSLATE),
            'name'      => 'title',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'type'      => 'text'
          ),
          array(
            'title'         => __('Percentage (%)',TS_TRANSLATE),
            'name'          => 'percentage',
            'id'            => '',
            'class'         => '',
            'value'         => '50',
            'min_max_step'  => '-100,100,1',
            'type'          => 'numeric-slider'
          ),
          array(
            'title'     => __('Percentage Text',TS_TRANSLATE),
            'name'      => 'percentage_text',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'type'      => 'text'
          ),
          array(
            'title'     => __('Color',TS_TRANSLATE),
            'name'      => 'color',
            'id'        => '',
            'class'     => '',
            'choices'   => $ts_shortcode_colors_2,
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'     => __('Custom Color',TS_TRANSLATE),
            'name'      => 'custom_color',
            'id'        => '',
            'class'     => '',
            'color'     => '',
            'value'     => '',
            'type'      => 'colorpicker'
          )
        ),
        'type'          => 'group-content'
      )
    )

  ),
  array(
    'title'         => __('Social Icons',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'social_sc',
    'shortcode'     => '[ts_social]{content}[/ts_social]',
    'options'       => array(
      array(
        'title'         => __('Social Icon',TS_TRANSLATE),
        'shortcode'     => '[ts_icon{attr}]',
        'addbutton'     => __('Add New',TS_TRANSLATE),
        'removebutton'  => __('Remove This',TS_TRANSLATE),
        'options'       => array(
          array(
            'title'     => __('Icon',TS_TRANSLATE),
            'name'      => 'icon',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'toggle'    => 'hide',
            'social'    => 'true',
            'type'      => 'iconbox'
          ),
          array(
            'title'     => __('Tooltip Title',TS_TRANSLATE),
            'name'      => 'title',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'type'      => 'text'
          ),
          array(
            'title'     => __('URL',TS_TRANSLATE),
            'name'      => 'url',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'type'      => 'text'
          ),
          array(
            'title'     => __('Target',TS_TRANSLATE),
            'name'      => 'target',
            'id'        => '',
            'class'     => '',
            'choices'   => $ts_shortcode_target,
            'value'     => '',
            'type'      => 'select'
          )
        ),
        'type'          => 'group-content'
      )
    )
  ),
  array(
    'title'         => __('Table',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'table_sc',
    'shortcode'     => '[ts_table{attr}]{content}[/ts_table]',
    'options'       => array(
      array(
        'title'     => __('Color',TS_TRANSLATE),
        'name'      => 'color',
        'id'        => '',
        'dependid'  => 'table_sc_color',
        'class'     => '',
        'choices'   => $ts_shortcode_colors,
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Color',TS_TRANSLATE),
        'name'      => 'custom_color',
        'id'        => '',
        'class'     => '',
        'color'     => '#ffffff',
        'value'     => '#ffffff',
        'type'      => 'colorpicker',
        'depends'   => 'table_sc_color:custom'
      ),
      array(
        'title'     => __('Your Table',TS_TRANSLATE),
        'name'      => '',
        'id'        => '',
        'class'     => '',
        'rows'      => '22',
        'mode'      => 'content',
        'value'     => '<table>
  <tr>
<th class="ts-center ts-min">ID</th>
    <th>Month</th>
    <th>Savings</th>
  </tr>
  <tr>
<td class="ts-center">1</td>
    <td>January</td>
    <td>$100</td>
  </tr>
  <tr>
<td class="ts-center">2</td>
    <td>February</td>
    <td>$120</td>
  </tr>
</table>',
        'type'      => 'textarea'
      )
    )

  ),
  array(
    'title'         => __('Pricing Table',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'pricingtable_sc',
    'shortcode'     => '[ts_pricingtable{attr}]{content}[/ts_pricingtable]',
    'options'       => array(
      array(
        'title'     => __('Color',TS_TRANSLATE),
        'name'      => 'color',
        'id'        => '',
        'dependid'  => 'ptable_sc_color',
        'class'     => '',
        'choices'   => $ts_shortcode_colors,
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'     => __('Color',TS_TRANSLATE),
        'name'      => 'custom_color',
        'id'        => '',
        'class'     => '',
        'color'     => '#33ccff',
        'value'     => '#33ccff',
        'type'      => 'colorpicker',
        'depends'   => 'ptable_sc_color:custom'
      ),
      array(
        'title'     => __('Highlight',TS_TRANSLATE),
        'name'      => 'highlight',
        'id'        => '',
        'class'     => '',
        'value'     => 'off',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Heading',TS_TRANSLATE),
        'name'      => 'title',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Price Text',TS_TRANSLATE),
        'name'      => 'price_text',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Currency',TS_TRANSLATE),
        'name'      => 'sup_text',
        'id'        => '',
        'class'     => '',
        'value'     => '$',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Period',TS_TRANSLATE),
        'name'      => 'sub_text',
        'id'        => '',
        'class'     => '',
        'value'     => '/ MO',
        'type'      => 'text'
      ),
      array(
        'title'     => __('Feature List',TS_TRANSLATE),
        'name'      => '',
        'id'        => '',
        'class'     => '',
        'rows'      => '12',
        'mode'      => 'content',
        'value'     => '<ul>
<li>...</li>
<li>...</li>
<li>[ts_button title="JOIN US" size="large" color="darkblue"][/ts_button]</li>
</ul>',
        'type'      => 'textarea'
      )
    )

  ),
  array(
    'title'         => __('Twitter',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'twitter_sc',
    'shortcode'     => '[ts_twitter{attr}]',
    'options'       => array(
      array(
        'title'     => __('Twitter User Name',TS_TRANSLATE),
        'name'      => 'user_name',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      ),
      array(
        'title'         => __('How Many Tweets?',TS_TRANSLATE),
        'name'          => 'count',
        'id'            => '',
        'class'         => '',
        'value'         => '2',
        'min_max_step'  => '1,15,1',
        'type'          => 'numeric-slider'
      ),
      array(
        'title'     => __('Replies',TS_TRANSLATE),
        'name'      => 'replies',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Retweeted',TS_TRANSLATE),
        'name'      => 'retweeted',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      )
    )

  ),
  array(
    'title'         => __('Photo Stream',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'photostream_sc',
    'shortcode'     => '{content}',
    'options'       => array(
      array(
        'title'     => __('Type',TS_TRANSLATE),
        'name'      => 'type',
        'id'        => '',
        'mode'      => 'fake',
        'dependid'  => 'photostream_sc_type',
        'class'     => '',
        'choices'   => array(
          array(
            'label' => __('Gallery',TS_TRANSLATE),
            'value' => 'gallery'
          ),
          array(
            'label' => __('Instagram',TS_TRANSLATE),
            'value' => 'instagram'
          ),
          array(
            'label' => __('Flickr',TS_TRANSLATE),
            'value' => 'flickr'
          )
        ),
        'value'     => '',
        'type'      => 'select'
      ),
      array(
        'title'         => __('Gallery',TS_TRANSLATE),
        'shortcode'     => '[ts_photostream{attr}]',
        'addbutton'     => false,
        'removebutton'  => '',
        'options'       => array(
          array(
            'title'     => __('Images',TS_TRANSLATE),
            'name'      => 'id',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'live'      => 'true',
            'multi'     => 'true',
            'type'      => 'upload'
          ),
          array(
            'title'     => __('First image bigger than others',TS_TRANSLATE),
            'name'      => 'first_big',
            'id'        => '',
            'class'     => '',
            'value'     => 'on',
            'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'      => 'switch'
          )
        ),
        'type'      => 'group-content',
        'depends'   => 'photostream_sc_type:gallery'
      ),
      array(
        'title'         => __('Instagram',TS_TRANSLATE),
        'shortcode'     => '[ts_instagram{attr}]',
        'addbutton'     => false,
        'removebutton'  => '',
        'options'       => array(
          array(
            'title'     => __('User ID',TS_TRANSLATE),
            'name'      => 'user_id',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'type'      => 'text'
          ),
          array(
            'title'         => __('How Many Items?',TS_TRANSLATE),
            'name'          => 'count',
            'id'            => '',
            'class'         => '',
            'value'         => '6',
            'min_max_step'  => '1,20,1',
            'type'          => 'numeric-slider'
          ),
          array(
            'title'     => __('First image bigger than others',TS_TRANSLATE),
            'name'      => 'first_big',
            'id'        => '',
            'class'     => '',
            'value'     => 'on',
            'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'      => 'switch'
          ),
          array(
            'title'     => __('Open with',TS_TRANSLATE),
            'name'      => 'open_url',
            'id'        => '',
            'class'     => 'big_switch',
            'value'     => 'on',
            'text'      => __('URL',TS_TRANSLATE).':'.__('LIGHTBOX',TS_TRANSLATE),
            'type'      => 'switch'
          )
        ),
        'type'          => 'group-content',
        'depends'       => 'photostream_sc_type:instagram'
      ),
      array(
        'title'         => __('Flickr',TS_TRANSLATE),
        'shortcode'     => '[ts_flickr{attr}]',
        'addbutton'     => false,
        'removebutton'  => '',
        'options'       => array(
          array(
            'title'     => __('User ID',TS_TRANSLATE),
            'name'      => 'user_id',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'type'      => 'text'
          ),
          array(
            'title'         => __('How Many Items?',TS_TRANSLATE),
            'name'          => 'count',
            'id'            => '',
            'class'         => '',
            'value'         => '6',
            'min_max_step'  => '1,20,1',
            'type'          => 'numeric-slider'
          ),
          array(
            'title'     => __('First image bigger than others',TS_TRANSLATE),
            'name'      => 'first_big',
            'id'        => '',
            'class'     => '',
            'value'     => 'on',
            'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'      => 'switch'
          ),
          array(
            'title'     => __('Open with',TS_TRANSLATE),
            'name'      => 'open_url',
            'id'        => '',
            'class'     => 'big_switch',
            'value'     => 'on',
            'text'      => __('URL',TS_TRANSLATE).':'.__('LIGHTBOX',TS_TRANSLATE),
            'type'      => 'switch'
          )
        ),
        'type'          => 'group-content',
        'depends'       => 'photostream_sc_type:flickr'
      )

    )

  ),
  array(
    'title'         => __('Our Clients',TS_TRANSLATE),
    'id'            => TS_PLUGIN.'ourclients_sc',
    'shortcode'     => '[ts_clients{attr}]{content}[/ts_clients]',
    'options'       => array(
      array(
        'title'     => __('Auto Play',TS_TRANSLATE),
        'name'      => 'autoplay',
        'id'        => '',
        'dependid'  => 'ourclients_sc_autoplay',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Stop on Hover',TS_TRANSLATE),
        'name'      => 'stop_hover',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch',
        'depends'   => 'ourclients_sc_autoplay:on'
      ),
      array(
        'title'     => __('Pagination',TS_TRANSLATE),
        'name'      => 'pagination',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Touch Drag',TS_TRANSLATE),
        'name'      => 'touch_drag',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'     => __('Grayscale Effect',TS_TRANSLATE),
        'name'      => 'grayscale',
        'id'        => '',
        'class'     => '',
        'value'     => 'on',
        'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
        'type'      => 'switch'
      ),
      array(
        'title'         => __('Slide Duration Time (second)',TS_TRANSLATE),
        'name'          => 'duration_time',
        'id'            => '',
        'class'         => '',
        'value'         => '4',
        'min_max_step'  => '2,30,1',
        'type'          => 'numeric-slider',
        'depends'       => 'ourclients_sc_autoplay:on'
      ),
      array(
        'title'         => __('Show Max Items (Wide)',TS_TRANSLATE),
        'name'          => 'show_max_item',
        'id'            => '',
        'class'         => '',
        'value'         => '6',
        'min_max_step'  => '4,10,1',
        'type'          => 'numeric-slider'
      ),
      array(
        'title'         => __('Show Max Items (Desktop)',TS_TRANSLATE),
        'name'          => 'show_max_desktop',
        'id'            => '',
        'class'         => '',
        'value'         => '4',
        'min_max_step'  => '2,10,1',
        'type'          => 'numeric-slider'
      ),
      array(
        'title'         => __('Show Max Items (Tablet)',TS_TRANSLATE),
        'name'          => 'show_max_tablet',
        'id'            => '',
        'class'         => '',
        'value'         => '2',
        'min_max_step'  => '1,10,1',
        'type'          => 'numeric-slider'
      ),
      array(
        'title'         => __('Show Max Items (Mobile)',TS_TRANSLATE),
        'name'          => 'show_max_mobile',
        'id'            => '',
        'class'         => '',
        'value'         => '1',
        'min_max_step'  => '1,10,1',
        'type'          => 'numeric-slider'
      ),
      array(
        'title'         => __('A Client',TS_TRANSLATE),
        'shortcode'     => '[ts_client{attr}]{content}[/ts_client]',
        'addbutton'     => __('Add New',TS_TRANSLATE),
        'removebutton'  => __('Remove This',TS_TRANSLATE),
        'options'       => array(
          array(
            'title'     => __('Image',TS_TRANSLATE),
            'name'      => 'src',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'live'      => '',
            'type'      => 'upload'
          ),
          array(
            'title'     => __('URL',TS_TRANSLATE),
            'name'      => 'url',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'type'      => 'text'
          ),
          array(
            'title'     => __('Target',TS_TRANSLATE),
            'name'      => 'target',
            'id'        => '',
            'class'     => '',
            'choices'   => $ts_shortcode_target,
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'     => __('Color',TS_TRANSLATE),
            'name'      => 'color',
            'id'        => '',
            'class'     => '',
            'choices'   => $ts_shortcode_colors_2,
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'     => __('Color',TS_TRANSLATE),
            'name'      => 'custom_color',
            'id'        => '',
            'class'     => '',
            'color'     => '',
            'value'     => '',
            'type'      => 'colorpicker'
          )
        ),
        'type'          => 'group-content'
      )
    )
  ),
  array(
    'title'             => __('Gap',TS_TRANSLATE),
    'id'                => TS_PLUGIN.'gap_sc',
    'shortcode'         => '[ts_gap{attr}]',
    'options'       => array(
      array(
        'title'     => __('Size',TS_TRANSLATE),
        'name'      => 'size',
        'id'        => '',
        'class'     => '',
        'value'     => '',
        'type'      => 'text'
      )
    )
  ),
  array(
    'title'             => __('Line',TS_TRANSLATE),
    'id'                => TS_PLUGIN.'line_sc',
    'shortcode'         => '[ts_line]'
  ),
  array(
    'title'             => __('Clear',TS_TRANSLATE),
    'id'                => TS_PLUGIN.'clear_sc',
    'shortcode'         => '[ts_clear]'
  )
);

  return array_merge($args,$themesama_settings);

}

}

if( !function_exists('rev_plugin_options_for_ts') ) {

  function rev_plugin_options_for_ts($args) {

    global $wpdb;
    $sql_q = $wpdb->get_results('SELECT id, title, alias FROM '.$wpdb->prefix.'revslider_sliders ORDER BY id ASC');
    $revsliders = array();

    if ($sql_q) {
      foreach ( $sql_q as $slider ) {
        $revsliders[] = array('label' => $slider->title, 'value' => $slider->alias);
      }
    }

    $plugin_settings = array(
      array(
        'title'         => __('Revolution Slider',TS_TRANSLATE),
        'id'            => 'rev_slider',
        'shortcode'     => '[rev_slider{attr}]',
        'options'       => array(
          array(
            'title'     => __('Choose a slider',TS_TRANSLATE),
            'name'      => 'alias',
            'id'        => '',
            'class'     => '',
            'choices'   => $revsliders,
            'value'     => '',
            'type'      => 'select'
          ),
        )
      )
    );
    
    return array_merge($args,$plugin_settings);
  }

}

if( !function_exists('cf7_plugin_options_for_ts') ) {

  function cf7_plugin_options_for_ts($args) {

    global $wpdb;
    $sql_q = $wpdb->get_results('SELECT ID, post_title FROM '.$wpdb->posts.' WHERE post_type = "wpcf7_contact_form"');
    $c_forms = array();

    if ($sql_q) {
      foreach ( $sql_q as $c_form ) {
        $c_forms[] = array('label' => $c_form->post_title, 'value' => $c_form->ID);
      }
    }

    $plugin_settings = array(
      array(
        'title'         => __('Contact Form 7',TS_TRANSLATE),
        'id'            => 'contact_form_7',
        'shortcode'     => '[contact-form-7{attr}]',
        'options'       => array(
          array(
            'title'     => __('Title',TS_TRANSLATE),
            'name'      => 'title',
            'id'        => '',
            'class'     => '',
            'value'     => '',
            'type'      => 'text'
          ),
          array(
            'title'     => __('Choose a contact form',TS_TRANSLATE),
            'name'      => 'id',
            'id'        => '',
            'class'     => '',
            'choices'   => $c_forms,
            'value'     => '',
            'type'      => 'select'
          )
        )
      )
    );
    
    return array_merge($args,$plugin_settings);
  }

}

if( !function_exists('slupy_shortcode_options_for_ts') ) {

  function slupy_shortcode_options_for_ts($args) {

    foreach (get_intermediate_image_sizes() as $key => $image_size) {
      $all_image_size[] = array('label' => $image_size, 'value' => $image_size);
    }

    $slupy_settings = array(
      array(
        'title'         => __('Portfolio',TS_TRANSLATE),
        'id'            => 'slupy_portfolio',
        'shortcode'     => '[slupy_portfolio{attr}]',
        'options'       => array(
          array(
            'title'     => __('Thumbnail Model',TS_TRANSLATE),
            'name'      => 'model',
            'id'        => '',
            'dependid'  => 'portfolio_model',
            'class'     => '',
            'choices'   => array(
              array(
                'label'     => __('Model 1',TS_TRANSLATE),
                'value'     => '1'
              ),
              array(
                'label'     => __('Model 2',TS_TRANSLATE),
                'value'     => '2'
              ),
              array(
                'label'     => __('Model 3',TS_TRANSLATE),
                'value'     => '3'
              )
            ),
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'     => __('List Type',TS_TRANSLATE),
            'name'      => 'masonry',
            'id'        => '',
            'dependid'  => 'portfolio_masonry',
            'depends'   => 'portfolio_model:1|2',
            'class'     => 'big_switch',
            'value'     => 'on',
            'text'      => __('MASONRY',TS_TRANSLATE).':'.__('GRID',TS_TRANSLATE),
            'type'      => 'switch'
          ),
          array(
            'title'     => __('Fit Grid Height?',TS_TRANSLATE),
            'name'      => 'fit_grid',
            'id'        => '',
            'depends'   => 'portfolio_model:1|2 + portfolio_masonry:off',
            'class'     => '',
            'value'     => 'on',
            'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'      => 'switch'
          ),
          array(
            'title'     => __('Loop Items Padding?',TS_TRANSLATE),
            'name'      => 'padding',
            'id'        => '',
            'depends'   => 'portfolio_model:1|2',
            'class'     => '',
            'value'     => 'on',
            'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'      => 'switch'
          ),
          array(
            'title'     => __('Filterable',TS_TRANSLATE),
            'name'      => 'filterable',
            'id'        => '',
            'class'     => '',
            'value'     => 'on',
            'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'      => 'switch'
          ),
          array(
            'title'     => __('Portfolio Max Columns',TS_TRANSLATE),
            'name'      => 'max_columns',
            'id'        => '',
            'class'     => '',
            'choices'   => array(
              array(
                'label' => '2',
                'value' => '2'
              ),
              array(
                'label' => '3',
                'value' => '3'
              ),
              array(
                'label' => '4',
                'value' => '4'
              ),
              array(
                'label' => '5',
                'value' => '5'
              )
            ),
            'value'     => '3',
            'type'      => 'select'
          ),
          array(
            'title'     => __('Pagination Style',TS_TRANSLATE),
            'name'      => 'pagination',
            'id'        => '',
            'class'     => '',
            'choices'   => array(
              array(
                'label'     => __('Load More',TS_TRANSLATE),
                'value'     => 'loadmore'
              ),
              array(
                'label'     => __('Older & Newer Button',TS_TRANSLATE),
                'value'     => 'oldernewer'
              ),
              array(
                'label'     => __('Page Numbers',TS_TRANSLATE),
                'value'     => 'pagenumbers'
              )
            ),
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'         => __('Portfolio Per Page',TS_TRANSLATE),
            'name'          => 'posts_per_page',
            'id'            => '',
            'class'         => '',
            'value'         => '10',
            'min_max_step'  => '2,30,1',
            'type'          => 'numeric-slider'
          ),
          array(
            'title'     => __('Image Size',TS_TRANSLATE),
            'name'      => 'image_size',
            'id'        => '',
            'class'     => '',
            'choices'   => $all_image_size,
            'value'     => '',
            'type'      => 'select'
          )
        )
      ),
      array(
        'title'         => __('Latest Projects',TS_TRANSLATE),
        'id'            => 'slupy_cportfolio',
        'shortcode'     => '[slupy_cportfolio{attr}]',
        'options'       => array(
          array(
            'title'     => __('Thumbnail Model',TS_TRANSLATE),
            'name'      => 'model',
            'id'        => '',
            'class'     => '',
            'choices'   => array(
              array(
                'label'     => __('Model 1',TS_TRANSLATE),
                'value'     => '1'
              ),
              array(
                'label'     => __('Model 2',TS_TRANSLATE),
                'value'     => '2'
              )
            ),
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'         => __('Limit',TS_TRANSLATE),
            'name'          => 'limit',
            'id'            => '',
            'class'         => '',
            'value'         => '8',
            'min_max_step'  => '4,12,1',
            'type'          => 'numeric-slider'
          ),
          array(
            'title'     => __('Image Size',TS_TRANSLATE),
            'name'      => 'image_size',
            'id'        => '',
            'class'     => '',
            'choices'   => $all_image_size,
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'     => __('Auto Play',TS_TRANSLATE),
            'name'      => 'autoplay',
            'id'        => '',
            'class'     => '',
            'value'     => 'on',
            'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'      => 'switch'
          ),
          array(
            'title'     => __('Stop on Hover',TS_TRANSLATE),
            'name'      => 'stop_hover',
            'id'        => '',
            'class'     => '',
            'value'     => 'on',
            'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'      => 'switch',
          ),
          array(
            'title'     => __('Pagination',TS_TRANSLATE),
            'name'      => 'pagination',
            'id'        => '',
            'class'     => '',
            'value'     => 'on',
            'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'      => 'switch'
          ),
          array(
            'title'     => __('Touch Drag',TS_TRANSLATE),
            'name'      => 'touch_drag',
            'id'        => '',
            'class'     => '',
            'value'     => 'on',
            'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'      => 'switch'
          ),
          array(
            'title'         => __('Slide Duration Time (second)',TS_TRANSLATE),
            'name'          => 'duration_time',
            'id'            => '',
            'class'         => '',
            'value'         => '4',
            'min_max_step'  => '2,30,1',
            'type'          => 'numeric-slider',
            'depends'       => 'ourclients_sc_autoplay:on'
          ),
          array(
            'title'         => __('Show Max Items (Wide)',TS_TRANSLATE),
            'name'          => 'show_max_item',
            'id'            => '',
            'class'         => '',
            'value'         => '4',
            'min_max_step'  => '2,10,1',
            'type'          => 'numeric-slider'
          ),
          array(
            'title'         => __('Show Max Items (Desktop)',TS_TRANSLATE),
            'name'          => 'show_max_desktop',
            'id'            => '',
            'class'         => '',
            'value'         => '3',
            'min_max_step'  => '2,10,1',
            'type'          => 'numeric-slider'
          ),
          array(
            'title'         => __('Show Max Items (Tablet)',TS_TRANSLATE),
            'name'          => 'show_max_tablet',
            'id'            => '',
            'class'         => '',
            'value'         => '2',
            'min_max_step'  => '1,10,1',
            'type'          => 'numeric-slider'
          ),
          array(
            'title'         => __('Show Max Items (Mobile)',TS_TRANSLATE),
            'name'          => 'show_max_mobile',
            'id'            => '',
            'class'         => '',
            'value'         => '1',
            'min_max_step'  => '1,10,1',
            'type'          => 'numeric-slider'
          )
        )
      ),
      array(
        'title'         => __('Blog',TS_TRANSLATE),
        'id'            => 'slupy_blog',
        'shortcode'     => '[slupy_blog{attr}]',
        'options'       => array(
          array(
            'title'     => __('Masonry Style',TS_TRANSLATE),
            'name'      => 'masonry',
            'id'        => '',
            'dependid'  => 'masonry_style',
            'class'     => '',
            'value'     => 'on',
            'text'      => __('ON',TS_TRANSLATE).':'.__('OFF',TS_TRANSLATE),
            'type'      => 'switch'
          ),
          array(
            'title'     => __('Masonry Max Columns',TS_TRANSLATE),
            'name'      => 'masonry_columns',
            'id'        => '',
            'depends'   => 'masonry_style:on',
            'class'     => '',
            'choices'   => array(
              array(
                'label' => '2',
                'value' => '2'
              ),
              array(
                'label' => '3',
                'value' => '3'
              ),
              array(
                'label' => '4',
                'value' => '4'
              )
            ),
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'     => __('Masonry Effect',TS_TRANSLATE),
            'name'      => 'effect',
            'id'        => '',
            'depends'   => 'masonry_style:on',
            'class'     => '',
            'choices'   => array(
              array(
                'label'     => __('fade',TS_TRANSLATE),
                'value'     => 'fadeIn'
              ),
              array(
                'label'     => __('fadeInDown',TS_TRANSLATE),
                'value'     => 'fadeInDown'
              ),
              array(
                'label'     => __('fadeInUp',TS_TRANSLATE),
                'value'     => 'fadeInUp'
              ),
              array(
                'label'     => __('bounceIn',TS_TRANSLATE),
                'value'     => 'bounceIn'
              ),
              array(
                'label'     => __('flipInX',TS_TRANSLATE),
                'value'     => 'flipInX'
              ),
              array(
                'label'     => __('flipInY',TS_TRANSLATE),
                'value'     => 'flipInY'
              )
            ),
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'         => __('Posts Per Page',TS_TRANSLATE),
            'name'          => 'posts_per_page',
            'id'            => '',
            'class'         => '',
            'value'         => '10',
            'min_max_step'  => '2,30,1',
            'type'          => 'numeric-slider'
          ),
          array(
            'title'     => __('Pagination Style',TS_TRANSLATE),
            'name'      => 'pagination',
            'id'        => '',
            'class'     => '',
            'choices'   => array(
              array(
                'label'     => __('Load More',TS_TRANSLATE),
                'value'     => 'loadmore'
              ),
              array(
                'label'     => __('Older & Newer Button',TS_TRANSLATE),
                'value'     => 'oldernewer'
              ),
              array(
                'label'     => __('Page Numbers',TS_TRANSLATE),
                'value'     => 'pagenumbers'
              )
            ),
            'value'     => '',
            'type'      => 'select'
          ),
          array(
            'title'     => __('Meta Position',TS_TRANSLATE),
            'name'      => 'meta_position',
            'id'        => '',
            'class'     => '',
            'choices'   => array(
              array(
                'label'     => __('Content After',TS_TRANSLATE),
                'value'     => 'content-after'
              ),
              array(
                'label'     => __('Media After',TS_TRANSLATE),
                'value'     => 'media-after'
              ),
              array(
                'label'     => __('Heading After',TS_TRANSLATE),
                'value'     => 'heading-after'
              ),
              array(
                'label'     => __('Together with Read More Button',TS_TRANSLATE),
                'value'     => 'read-more'
              )
            ),
            'value'     => '',
            'type'      => 'select'
          ),
        )
      )
    );
    return array_merge($args,$slupy_settings);
  }

}


/*---------------------------------------------
  Filters
---------------------------------------------*/
add_filter('themesama_shortcode_manager_options', 'columns_layout_options', 10);
add_filter('themesama_shortcode_manager_options', 'themesama_options_values', 13);
add_filter('themesama_shortcode_manager_options', 'slupy_shortcode_options_for_ts', 14);

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

if( is_plugin_active('revslider/revslider.php') ){
  add_filter('themesama_shortcode_manager_options', 'rev_plugin_options_for_ts', 13);
}

if( is_plugin_active('contact-form-7/wp-contact-form-7.php') ){
  add_filter('themesama_shortcode_manager_options', 'cf7_plugin_options_for_ts', 14);
}

?>