<?php
extract(shortcode_atts(array(
  'el_class' => ''
), $atts));

$output = '';
$css_class = 'column-text'.($el_class != '' ? ' '.$el_class : '');

$output .= '<div class="'.esc_attr( $css_class ).'">';
$output .= wpb_js_remove_wpautop( $content, true );
$output .= '</div> ';

echo $output;